// Punto de entrada del Paso 5.
// Flujo: seed + aprobadas -> portada -> ubicación -> clima -> selección ->
// dispersión -> audio -> lente -> donación. El clima es invisible: solo se lee
// en ?debug=1. Una donación nunca altera la composición en curso.

import { CONFIG } from './config.js';
import { createSeedImages } from './seed/images.js';
import { createSeedAudio } from './seed/audio.js';
import { fetchWeather } from './weather/open-meteo.js';
import { neutralProfile, profileFromMock, profileFromWeather } from './weather/profile.js';
import { selectPieces, selectAudio } from './composition/select.js';
import { layoutPieces } from './composition/layout.js';
import { renderGallery } from './render/gallery.js';
import { createAudioEngine } from './audio/engine.js';
import { initEntry } from './ui/entry.js';
import { initAbout } from './ui/about.js';
import { requestLocation } from './ui/location.js';
import { initLens } from './ui/lens.js';
import { initDonate } from './ui/donate.js';
import { initDebug } from './ui/debug.js';
import {
  fetchApprovedPieces,
  getApprovedHashes,
  mergePieces,
  startSignedUrlRefresh,
} from './supabase/pieces.js';
import { isSupabaseConfigured } from './supabase/client.js';
import { getOwnIds } from './storage/local.js';
import { state } from './state.js';

const params = new URLSearchParams(window.location.search);
const debug = CONFIG.debug || params.get('debug') === '1';
const mockProfile = profileFromMock(params.get('mock'));

state.debug = debug;

if (!isSupabaseConfigured()) {
  console.info('[pozo] Supabase sin configurar: la obra usa solo el seed.');
}

const stage = document.querySelector('#stage');
const status = document.querySelector('#entry-status');

if (!stage) {
  throw new Error('Falta el campo de fragmentos en el documento.');
}

function createSessionId() {
  if (window.crypto?.randomUUID) return window.crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function localDateKey() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${now.getFullYear()}-${month}-${day}`;
}

let compositionMeta = null;
let audioState = null;
const updateDebug = debug ? initDebug() : null;

// Control de sonido: visible solo cuando hay capas activas.
const muteButton = document.createElement('button');
muteButton.type = 'button';
muteButton.className = 'mute';
muteButton.hidden = true;
muteButton.setAttribute('aria-pressed', 'false');
muteButton.setAttribute('aria-label', 'silenciar audio');
muteButton.textContent = 'sonido';
document.body.append(muteButton);

const audio = createAudioEngine({ onChange: () => refreshAudioUi() });

function refreshAudioUi() {
  audioState = audio.getState();
  muteButton.hidden = audioState.layers.length === 0;

  const muted = audioState.muted;
  muteButton.textContent = muted ? 'silencio' : 'sonido';
  muteButton.setAttribute('aria-pressed', String(muted));
  muteButton.setAttribute('aria-label', muted ? 'activar audio' : 'silenciar audio');

  if (updateDebug && state.profile) {
    updateDebug(state, compositionMeta, audioState);
  }
}

muteButton.addEventListener('click', () => {
  audio.toggleMute();
});

// En debug, el nivel y el estado se leen mientras los fades avanzan.
if (updateDebug) {
  window.setInterval(() => {
    if (!state.entered || document.visibilityState === 'hidden') return;
    refreshAudioUi();
  }, 800);
}

const imageSeed = createSeedImages().catch((error) => {
  if (debug) console.warn('No se pudo generar el seed de imágenes:', error);
  return [];
});

const audioSeed = createSeedAudio().catch((error) => {
  if (debug) console.warn('No se pudo generar el seed de audio:', error);
  return [];
});

const seedReady = Promise.all([imageSeed, audioSeed])
  .then(([images, audios]) => ({ images, audios }));

// La lectura compartida corre en paralelo con el seed. Si Supabase no está
// configurado o falla, `approvedReady` resuelve vacío y el pozo sigue igual.
const approvedReady = fetchApprovedPieces().catch((error) => {
  if (debug) console.warn('No se pudieron leer las piezas aprobadas:', error);
  return { pieces: [], status: null };
});

const matterReady = Promise.all([seedReady, approvedReady])
  .then(([seed, remote]) => {
    const ownIds = getOwnIds();
    const own = new Set(ownIds);
    const approved = (remote.pieces ?? []).filter((piece) => piece && !own.has(piece.id));
    const approvedAudio = approved.filter((piece) => piece.kind === 'audio');

    state.seedPieces = seed.images;
    state.audioSeed = [...seed.audios, ...approvedAudio];
    state.pieces = mergePieces([...seed.images, ...seed.audios], approved, ownIds);
    state.remotePieces = remote.pieces ?? [];
    state.approvedPieces = approved;
    state.remoteStatus = remote.status ?? null;
    state.ownIds = ownIds;
    state.ready = true;

    return state.pieces;
  });

matterReady.then(() => {
  if (!isSupabaseConfigured() || state.approvedPieces.length === 0) return;

  startSignedUrlRefresh((pieces, info) => {
    // El panel de debug refleja la firma nueva sin recomponer el campo.
    state.remoteStatus = info;
    if (!debug) return;
    console.info(`[pozo] URLs firmadas renovadas: ${info.refreshed}/${pieces.length}.`);
  });
});

initAbout();
initLens({ stage, getState: () => state, audio });

const donation = initDonate({
  stage,
  state,
  getKnownHashes: getApprovedHashes,
  extraInert: [muteButton],
  onChange: () => {
    if (updateDebug) updateDebug(state, compositionMeta, audioState);
  },
});

function paint() {
  const placements = layoutPieces(state.selected, {
    width: window.innerWidth,
    height: window.innerHeight,
    profile: state.profile,
    seed: `${state.compositionSeed}|layout`,
  });

  state.placements = placements;

  renderGallery(stage, placements, {
    debug,
    profile: state.profile,
    seed: state.compositionSeed,
  });

  if (updateDebug) updateDebug(state, compositionMeta, audioState);
}

async function enterPozo() {
  let location = {
    lat: CONFIG.defaultCity.lat,
    lon: CONFIG.defaultCity.lon,
    source: 'default',
  };
  let weather = null;

  if (mockProfile) {
    state.weatherSource = 'mock';
    state.locationSource = 'mock';
  } else {
    location = await requestLocation();
    state.locationSource = location.source;
    state.weatherSource = 'consultando';

    if (status) status.textContent = 'eligiendo materia…';

    weather = await fetchWeather(location);
    state.weatherSource = weather ? 'open-meteo' : 'neutral';
  }

  state.mock = mockProfile?.mock ?? null;
  state.profile = mockProfile ?? (weather ? profileFromWeather(weather) : neutralProfile());
  state.sessionId = createSessionId();
  state.compositionSeed = `${state.profile.seedBase}|${localDateKey()}|${state.sessionId}`;

  const selection = selectPieces(state.pieces, state.profile, {
    seed: `${state.compositionSeed}|select`,
    mobile: window.innerWidth < 720,
  });

  const audioSelection = selectAudio(state.audioSeed, state.profile, {
    seed: `${state.compositionSeed}|audio`,
  });

  state.selected = [...selection.items, ...audioSelection.items];
  state.selectionMeta = selection.meta;
  state.audioSelected = audioSelection.items;
  state.audioMeta = audioSelection.meta;
  compositionMeta = selection.meta;
  state.entered = true;

  paint();
  audio.start(audioSelection.items, state.profile).catch(() => {
    // Un fallo de audio no impide ver el campo.
  });
  donation.show();
}

initEntry({
  stage,
  ready: matterReady,
  onEnter: enterPozo,
  onUnlock: () => audio.unlock(),
});

let resizeTimer = 0;

window.addEventListener('resize', () => {
  if (!state.entered) return;

  window.clearTimeout(resizeTimer);
  resizeTimer = window.setTimeout(() => {
    // Misma selección, nuevas posiciones. La composición no se rehace.
    paint();
  }, 180);
}, { passive: true });

// Si la materia tarda, la portada lo dice sin bloquear la lectura.
matterReady.then((pieces) => {
  if (!state.entered && status && pieces.length === 0) {
    status.textContent = 'la materia no cargó. igual podés entrar al pozo vacío.';
  }
});
