// Punto de entrada del Paso 3.
// Flujo: seed -> portada -> ubicación -> clima -> selección -> dispersión ->
// audio -> lente. El clima es invisible: solo se lee en ?debug=1.

import { CONFIG } from './config.js';
import { createSeedImages } from './seed/images.js';
import { createSeedAudio } from './seed/audio.js';
import { fetchWeather } from './weather/open-meteo.js';
import { neutralProfile, profileFromMock, profileFromWeather } from './weather/profile.js';
import { selectPieces, selectAudio } from './composition/select.js';
import { layoutPieces } from './composition/layout.js';
import { renderGallery } from './render/gallery.js';
import { createAudioEngine } from './audio/engine.js';
import { initEntry } from './ui/entry.js';
import { initAbout } from './ui/about.js';
import { requestLocation } from './ui/location.js';
import { initLens } from './ui/lens.js';
import { initDebug } from './ui/debug.js';
import { state } from './state.js';

const params = new URLSearchParams(window.location.search);
const debug = CONFIG.debug || params.get('debug') === '1';
const mockProfile = profileFromMock(params.get('mock'));

state.debug = debug;

const stage = document.querySelector('#stage');
const status = document.querySelector('#entry-status');

if (!stage) {
  throw new Error('Falta el campo de fragmentos en el documento.');
}

function createSessionId() {
  if (window.crypto?.randomUUID) return window.crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function localDateKey() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${now.getFullYear()}-${month}-${day}`;
}

let compositionMeta = null;
let audioState = null;
const updateDebug = debug ? initDebug() : null;

// Control de sonido: visible solo cuando hay capas activas.
const muteButton = document.createElement('button');
muteButton.type = 'button';
muteButton.className = 'mute';
muteButton.hidden = true;
muteButton.setAttribute('aria-pressed', 'false');
muteButton.setAttribute('aria-label', 'silenciar audio');
muteButton.textContent = 'sonido';
document.body.append(muteButton);

const audio = createAudioEngine({ onChange: () => refreshAudioUi() });

function refreshAudioUi() {
  audioState = audio.getState();
  muteButton.hidden = audioState.layers.length === 0;

  const muted = audioState.muted;
  muteButton.textContent = muted ? 'silencio' : 'sonido';
  muteButton.setAttribute('aria-pressed', String(muted));
  muteButton.setAttribute('aria-label', muted ? 'activar audio' : 'silenciar audio');

  if (updateDebug && state.profile) {
    updateDebug(state, compositionMeta, audioState);
  }
}

muteButton.addEventListener('click', () => {
  audio.toggleMute();
});

// En debug, el nivel y el estado se leen mientras los fades avanzan.
if (updateDebug) {
  window.setInterval(() => {
    if (!state.entered || document.visibilityState === 'hidden') return;
    refreshAudioUi();
  }, 800);
}

const imageSeed = createSeedImages().catch((error) => {
  if (debug) console.warn('No se pudo generar el seed de imágenes:', error);
  return [];
});

const audioSeed = createSeedAudio().catch((error) => {
  if (debug) console.warn('No se pudo generar el seed de audio:', error);
  return [];
});

const seedReady = Promise.all([imageSeed, audioSeed])
  .then(([images, audios]) => {
    state.seedPieces = images;
    state.audioSeed = audios;
    state.pieces = [...images, ...audios];
    state.ready = true;
    return state.pieces;
  });

initAbout();
initLens({ stage, getState: () => state, audio });

function paint() {
  const placements = layoutPieces(state.selected, {
    width: window.innerWidth,
    height: window.innerHeight,
    profile: state.profile,
    seed: `${state.compositionSeed}|layout`,
  });

  state.placements = placements;

  renderGallery(stage, placements, {
    debug,
    profile: state.profile,
    seed: state.compositionSeed,
  });

  if (updateDebug) updateDebug(state, compositionMeta, audioState);
}

async function enterPozo() {
  let location = {
    lat: CONFIG.defaultCity.lat,
    lon: CONFIG.defaultCity.lon,
    source: 'default',
  };
  let weather = null;

  if (mockProfile) {
    state.weatherSource = 'mock';
    state.locationSource = 'mock';
  } else {
    location = await requestLocation();
    state.locationSource = location.source;
    state.weatherSource = 'consultando';

    if (status) status.textContent = 'eligiendo materia…';

    weather = await fetchWeather(location);
    state.weatherSource = weather ? 'open-meteo' : 'neutral';
  }

  state.mock = mockProfile?.mock ?? null;
  state.profile = mockProfile ?? (weather ? profileFromWeather(weather) : neutralProfile());
  state.sessionId = createSessionId();
  state.compositionSeed = `${state.profile.seedBase}|${localDateKey()}|${state.sessionId}`;

  const selection = selectPieces(state.pieces, state.profile, {
    seed: `${state.compositionSeed}|select`,
    mobile: window.innerWidth < 720,
  });

  const audioSelection = selectAudio(state.audioSeed, state.profile, {
    seed: `${state.compositionSeed}|audio`,
  });

  state.selected = [...selection.items, ...audioSelection.items];
  state.selectionMeta = selection.meta;
  state.audioSelected = audioSelection.items;
  state.audioMeta = audioSelection.meta;
  compositionMeta = selection.meta;
  state.entered = true;

  paint();
  audio.start(audioSelection.items, state.profile).catch(() => {
    // Un fallo de audio no impide ver el campo.
  });
}

initEntry({
  stage,
  ready: seedReady,
  onEnter: enterPozo,
  onUnlock: () => audio.unlock(),
});

let resizeTimer = 0;

window.addEventListener('resize', () => {
  if (!state.entered) return;

  window.clearTimeout(resizeTimer);
  resizeTimer = window.setTimeout(() => {
    // Misma selección, nuevas posiciones. La composición no se rehace.
    paint();
  }, 180);
}, { passive: true });

// Si el seed tarda, la portada lo dice sin bloquear la lectura.
seedReady.then((pieces) => {
  if (!state.entered && status && pieces.length === 0) {
    status.textContent = 'la materia no cargó. igual podés entrar al pozo vacío.';
  }
});
