// Selección 80/20.
// La mayoría de las piezas se acerca al perfil climático; una minoría lo contradice.
// El azar está sembrado por clima, fecha y sesión, así que cada entrada varía.

import { CONFIG } from '../config.js';
import { makeRng } from '../seed/prng.js';

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function hueDistance(a, b) {
  const delta = Math.abs(((a - b) % 360 + 360) % 360);
  return Math.min(delta, 360 - delta) / 180;
}

function colorDistance(color, target) {
  if (!color || !target) return 0.5;

  const dh = hueDistance(Number(color.h ?? 0), Number(target.h ?? 0));
  const ds = Math.abs(Number(color.s ?? 0.5) - Number(target.s ?? 0.5));
  const dl = Math.abs(Number(color.l ?? 0.5) - Number(target.l ?? 0.5));

  return Math.sqrt(dh * dh * 1.7 + ds * ds * 1.15 + dl * dl * 1.1);
}

export function distanceToProfile(piece, profile) {
  const features = piece?.features ?? {};
  const target = {
    h: profile.hue,
    s: profile.saturation,
    l: profile.lightness,
  };

  const palette = Array.isArray(features.palette) ? features.palette : [];
  const paletteDistance = palette.length > 0
    ? Math.min(...palette.map((color) => colorDistance(color, target)))
    : 0.5;

  const meanDistance = colorDistance(features.mean, target);
  const brightnessDistance = Math.abs((features.brightness ?? 0.45) - profile.brightness);
  const saturationDistance = Math.abs((features.saturation ?? 0.5) - profile.saturation);

  return clamp(
    paletteDistance * 0.56
      + meanDistance * 0.24
      + brightnessDistance * 0.12
      + saturationDistance * 0.08,
    0,
    1,
  );
}

function shuffle(list, rng) {
  for (let i = list.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list;
}

export function selectPieces(pool, profile, options = {}) {
  const seed = options.seed ?? `${profile.seedBase}-selection`;
  const rng = makeRng(`pozo-select-${seed}`);
  const mobile = Boolean(options.mobile);
  const exclude = new Set(options.excludeIds ?? []);

  const available = (pool ?? []).filter((piece) => {
    return piece && piece.kind === 'image' && !exclude.has(piece.id);
  });

  const maxCount = Math.min(
    options.maxCount ?? CONFIG.composition.maxCount,
    CONFIG.composition.hardCap,
    available.length,
  );

  if (maxCount === 0) {
    return {
      items: [],
      meta: {
        count: 0,
        desired: 0,
        affinityCount: 0,
        contrastCount: 0,
        poolSize: 0,
        mobile,
        seed,
      },
    };
  }

  let desired = Math.round(
    CONFIG.composition.minCount
      + profile.density * (CONFIG.composition.maxCount - CONFIG.composition.minCount),
  );

  if (mobile) {
    desired = Math.round(desired * CONFIG.composition.mobileFactor);
    // Aun con el mismo pool, el móvil debe mostrar menos materia que el escritorio.
    desired = clamp(desired, 4, Math.max(4, maxCount - 1));
  }

  const count = Math.min(maxCount, desired);
  const ranked = available
    .map((piece) => ({
      piece,
      distance: distanceToProfile(piece, profile),
    }))
    .sort((a, b) => a.distance - b.distance);

  const affinityCount = Math.min(
    count,
    Math.max(1, Math.round(count * CONFIG.composition.affinityRatio)),
  );
  const contrastCount = count - affinityCount;

  const selected = [];
  const selectedIds = new Set();

  // Afinidad: se elige dentro del grupo más cercano, no siempre los primeros.
  const affinitySpan = Math.max(affinityCount, Math.ceil(ranked.length * 0.55));
  const affinityPool = shuffle(ranked.slice(0, affinitySpan), rng);

  for (const item of affinityPool) {
    if (selected.length >= affinityCount) break;
    if (selectedIds.has(item.piece.id)) continue;
    selected.push({ ...item, group: 'afinidad' });
    selectedIds.add(item.piece.id);
  }

  // Contraste: se elige dentro del extremo más lejano que quede disponible.
  if (contrastCount > 0) {
    const remaining = ranked.filter((item) => !selectedIds.has(item.piece.id));
    const contrastSpan = Math.max(contrastCount, Math.ceil(remaining.length * 0.55));
    const contrastPool = shuffle(remaining.slice(-contrastSpan), rng);

    for (const item of contrastPool) {
      if (selected.length >= count) break;
      if (selectedIds.has(item.piece.id)) continue;
      selected.push({ ...item, group: 'contraste' });
      selectedIds.add(item.piece.id);
    }
  }

  // Relleno de seguridad si los grupos no alcanzaron.
  for (const item of ranked) {
    if (selected.length >= count) break;
    if (selectedIds.has(item.piece.id)) continue;
    selected.push({ ...item, group: 'afinidad' });
    selectedIds.add(item.piece.id);
  }

  const items = shuffle(selected, rng).map((item) => ({
    ...item,
    distance: Number(item.distance.toFixed(4)),
  }));

  return {
    items,
    meta: {
      count: items.length,
      desired,
      affinityCount: items.filter((item) => item.group === 'afinidad').length,
      contrastCount: items.filter((item) => item.group === 'contraste').length,
      poolSize: available.length,
      mobile,
      seed,
    },
  };
}

// Afinidad sonora: el clima define un objetivo de centroide, planitud y nivel.
// Siempre se eligen 1 o 2 capas; si el pool está vacío, silencio.
const AUDIO_THRESHOLD = 0.62;
const AUDIO_SECOND_GAP = 0.2;

function audioTarget(profile) {
  const character = clamp(Number(profile?.audioCharacter ?? 0.4), 0, 1);
  const turbulence = clamp(Number(profile?.turbulence ?? 0.35), 0, 1);
  const decay = clamp(Number(profile?.decay ?? 0.4), 0, 1);

  return {
    centroid: 0.02 + character * 0.06 + turbulence * 0.02,
    flatness: 0.02 + turbulence * 0.18 + decay * 0.04,
    rms: 0.04 + (1 - decay) * 0.04 + character * 0.02,
  };
}

function audioDistance(features, target) {
  if (!features) return 1;

  const centroid = clamp(Number(features.centroidNorm ?? 0.1), 0, 1);
  const flatness = clamp(Number(features.flatness ?? 0.1), 0, 1);
  const rms = clamp(Number(features.rms ?? 0.08), 0, 1);

  // El nivel pesa poco: el motor ya normaliza el volumen de cada capa.
  // Lo que define la afinidad es el brillo (centroide) y la rugosidad (planitud).
  const dc = Math.abs(centroid - target.centroid) / 0.12;
  const df = Math.abs(flatness - target.flatness) / 0.3;
  const dr = Math.abs(rms - target.rms) / 0.25;

  return clamp(Math.sqrt(dc * dc * 0.58 + df * df * 0.34 + dr * dr * 0.08), 0, 1);
}

export function selectAudio(pool, profile, options = {}) {
  const seed = options.seed ?? `${profile?.seedBase ?? 'pozo'}-audio`;
  const rng = makeRng(`pozo-audio-${seed}`);
  const exclude = new Set(options.excludeIds ?? []);

  const available = (pool ?? []).filter((piece) => {
    return piece && piece.kind === 'audio' && !exclude.has(piece.id);
  });

  const target = audioTarget(profile);
  const ranked = available
    .map((piece) => ({
      piece,
      distance: audioDistance(piece.features, target),
    }))
    .sort((a, b) => a.distance - b.distance);

  const chosen = [];

  for (const item of ranked) {
    if (chosen.length >= 2) break;
    if (chosen.length === 0 && item.distance > AUDIO_THRESHOLD) break;

    // La segunda capa entra solo si no está demasiado lejos de la primera.
    if (chosen.length === 1) {
      const gap = item.distance - chosen[0].distance;
      if (gap > AUDIO_SECOND_GAP) break;
    }

    chosen.push({ ...item, group: 'audio' });
  }

  const items = shuffle(chosen, rng).map((item) => ({
    ...item,
    distance: Number(item.distance.toFixed(4)),
  }));

  return {
    items,
    meta: {
      count: items.length,
      desired: Math.min(2, available.length),
      poolSize: available.length,
      threshold: AUDIO_THRESHOLD,
      seed,
    },
  };
}
