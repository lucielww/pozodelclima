-- POZO DEL CLIMA — bucket privado y políticas de Storage.
-- Ejecutar después de schema.sql.
--
-- Lectura: nadie puede leer un objeto que no esté aprobado. Solo se pueden
-- firmar URLs (y listar los nombres) de objetos que tengan una fila `approved`
-- en public.pieces. La función es `security definer` para poder consultar la
-- tabla sin depender de la RLS del visitante.
--
-- Escritura: anon puede subir un objeto nuevo con nombre `<uuid>.ext`, pero no
-- puede actualizarlo ni borrarlo. La fila queda pendiente hasta la aprobación
-- manual en el dashboard.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'pozo',
  'pozo',
  false,
  12582912,
  array[
    'image/jpeg',
    'image/png',
    'image/webp',
    'audio/mpeg',
    'audio/ogg',
    'audio/wav',
    'audio/x-wav',
    'audio/mp4',
    'audio/x-m4a'
  ]
)
on conflict (id) do update set
  public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create or replace function public.pozo_is_approved_object(object_bucket text, object_name text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select object_bucket = 'pozo'
    and exists (
      select 1
      from public.pieces
      where storage_path = object_name
        and status = 'approved'
    );
$$;

revoke all on function public.pozo_is_approved_object(text, text) from public;
grant execute on function public.pozo_is_approved_object(text, text) to anon, authenticated;

drop policy if exists "pozo: leer objetos aprobados" on storage.objects;
create policy "pozo: leer objetos aprobados"
  on storage.objects
  for select
  to anon, authenticated
  using (public.pozo_is_approved_object(bucket_id, name));

drop policy if exists "pozo: subir pendientes" on storage.objects;
create policy "pozo: subir pendientes"
  on storage.objects
  for insert
  to anon, authenticated
  with check (
    bucket_id = 'pozo'
    and name ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(jpg|jpeg|png|webp|mp3|ogg|wav|m4a)$'
  );

-- No se crean políticas de update ni delete: Storage las rechaza para anon.
-- El listado no tiene una política aparte, pero la lectura deja ver los nombres
-- de los objetos aprobados (son públicos por diseño). Un `pending` no aparece.
