// Registro local de las donaciones hechas desde este navegador.
// El flujo de donación llega en el Paso 5; por ahora alcanza con leer los IDs
// propios para excluirlos de la composición. El registro guarda { id, path, at }
// bajo la clave `pozo.donations`, tal como pide el plan.

const STORAGE_KEY = 'pozo.donations';
const MAX_RECORDS = 50;

function readRaw() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    // Modo privado, cuota llena o JSON roto: la obra sigue sin registro.
    return [];
  }
}

function isRecord(value) {
  return Boolean(value)
    && typeof value === 'object'
    && typeof value.id === 'string'
    && value.id.length > 0;
}

export function getDonations() {
  return readRaw()
    .filter(isRecord)
    .slice(-MAX_RECORDS)
    .map((record) => ({
      id: record.id,
      path: typeof record.path === 'string' ? record.path : '',
      at: typeof record.at === 'string' ? record.at : '',
    }));
}

export function getOwnIds() {
  return [...new Set(getDonations().map((record) => record.id))];
}

export function addDonation(record) {
  if (!isRecord(record)) return getDonations();

  const donations = getDonations().filter((entry) => entry.id !== record.id);
  donations.push({
    id: record.id,
    path: typeof record.path === 'string' ? record.path : '',
    at: typeof record.at === 'string' ? record.at : new Date().toISOString(),
  });

  const trimmed = donations.slice(-MAX_RECORDS);

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
  } catch {
    // Si no se puede guardar, la donación igual sigue su curso en el Paso 5.
  }

  return trimmed;
}
