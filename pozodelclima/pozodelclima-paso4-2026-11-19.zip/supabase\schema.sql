-- POZO DEL CLIMA — esquema de piezas donadas.
-- Ejecutar en el SQL Editor del proyecto, antes de storage.sql.
-- Es idempotente: se puede volver a correr sin duplicar nada.
--
-- Reglas de seguridad:
--   * anon solo puede insertar filas `pending`;
--   * anon solo puede leer filas `approved`;
--   * anon no puede actualizar, borrar ni truncar;
--   * la aprobación se hace desde el dashboard con el rol de servicio.
--
-- El tipo `video` queda reservado para el Paso 7. La base lo acepta, pero el
-- bucket de storage todavía no habilita esos MIME.

create extension if not exists pgcrypto;

create table if not exists public.pieces (
  id uuid primary key default gen_random_uuid(),
  kind text not null,
  status text not null default 'pending',
  storage_path text not null,
  mime text not null,
  bytes bigint not null,
  width integer,
  height integer,
  duration_ms integer,
  sha256 text not null,
  features jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  approved_at timestamptz,

  constraint pieces_kind_check
    check (kind in ('image', 'audio', 'video')),

  constraint pieces_status_check
    check (status in ('pending', 'approved', 'rejected')),

  constraint pieces_sha256_check
    check (sha256 ~ '^[0-9a-f]{64}$'),

  constraint pieces_path_check
    check (storage_path ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(jpg|jpeg|png|webp|mp3|ogg|wav|m4a|mp4|webm)$'),

  constraint pieces_mime_check
    check (
      (kind = 'image' and mime in ('image/jpeg', 'image/png', 'image/webp'))
      or (kind = 'audio' and mime in ('audio/mpeg', 'audio/ogg', 'audio/wav', 'audio/x-wav', 'audio/mp4', 'audio/x-m4a'))
      or (kind = 'video' and mime in ('video/mp4', 'video/webm'))
    ),

  constraint pieces_bytes_check
    check (
      (kind = 'image' and bytes between 1 and 8 * 1024 * 1024)
      or (kind = 'audio' and bytes between 1 and 12 * 1024 * 1024)
      or (kind = 'video' and bytes between 1 and 20 * 1024 * 1024)
    ),

  constraint pieces_shape_check
    check (
      (kind = 'image' and width between 1 and 20000 and height between 1 and 20000 and duration_ms is null)
      or (kind = 'audio' and width is null and height is null and duration_ms between 1 and 90000)
      or (kind = 'video' and width between 1 and 8000 and height between 1 and 8000 and duration_ms between 1 and 30000)
    ),

  constraint pieces_features_check
    check (jsonb_typeof(features) = 'object')
);

-- Un archivo aprobado no puede entrar dos veces, ni siquiera con otro nombre.
create unique index if not exists pieces_sha256_key
  on public.pieces (sha256);

create index if not exists pieces_approved_idx
  on public.pieces (created_at desc)
  where status = 'approved';

create index if not exists pieces_storage_path_idx
  on public.pieces (storage_path);

-- `approved_at` se completa solo cuando el admin aprueba la fila.
-- Si vuelve a pendiente o se rechaza, se limpia.
create or replace function public.pozo_piece_status()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.status = 'approved' and new.approved_at is null then
    new.approved_at := now();
  elsif new.status <> 'approved' then
    new.approved_at := null;
  end if;

  return new;
end;
$$;

drop trigger if exists pieces_status_trigger on public.pieces;
create trigger pieces_status_trigger
  before insert or update on public.pieces
  for each row execute function public.pozo_piece_status();

alter table public.pieces enable row level security;

drop policy if exists "pozo: leer aprobadas" on public.pieces;
create policy "pozo: leer aprobadas"
  on public.pieces
  for select
  to anon, authenticated
  using (status = 'approved');

drop policy if exists "pozo: insertar pendientes" on public.pieces;
create policy "pozo: insertar pendientes"
  on public.pieces
  for insert
  to anon, authenticated
  with check (status = 'pending' and approved_at is null);

-- Sin políticas de update/delete: esas operaciones quedan cerradas para anon.
-- El service_role del dashboard las saltea por diseño.
revoke all on public.pieces from anon, authenticated;
grant select, insert on public.pieces to anon, authenticated;

-- Al insertar desde el cliente no se pida representación (`.select()`): la fila
-- nace `pending` y la política de lectura solo devuelve aprobadas. Usar el
-- insert sin `select` y quedarse con el UUID generado en el navegador.

-- Prueba manual desde el dashboard:
--
-- 1. Storage → bucket `pozo` → subir un archivo con nombre `<uuid>.webp`
--    (o `<uuid>.wav` para audio). El objeto nace privado.
-- 2. Calcular su SHA-256 real (PowerShell):
--      (Get-FileHash .\archivo.webp -Algorithm SHA256).Hash.ToLower()
-- 3. Insertar la fila ya aprobada:
--
--    insert into public.pieces
--      (kind, status, storage_path, mime, bytes, width, height, sha256, features)
--    values
--      ('image', 'approved', '<uuid>.webp', 'image/webp', 123456,
--       1600, 1000, '<sha256 de 64 caracteres>', '{}'::jsonb);
--
--    El trigger completa `approved_at`. Las `features` pueden quedar vacías:
--    la pieza igual aparece, con un perfil neutro, hasta que el Paso 5 las
--    calcule y las guarde.
-- 4. Recargar la obra: la fila entra en la próxima composición.
