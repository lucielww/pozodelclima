// Material de audio precargado: tres texturas abstractas de 12 s.
// Se renderizan con OfflineAudioContext y se entregan como WAV, igual que una
// pieza donada. No hay síntesis en vivo: el motor solo reproduce buffers.
// Semillas fijas: el seed suena igual en cada visita.

import { analyzeAudioBuffer } from '../analysis/audio.js';
import { int, makeRng, pick, range } from './prng.js';

const SAMPLE_RATE = 44100;
const DURATION = 12;
const EDGE_FADE = 0.012;

const SPECS = [
  { id: 'seed-aud-1', build: buildDrone },
  { id: 'seed-aud-2', build: buildGrains },
  { id: 'seed-aud-3', build: buildGrid },
];

export async function createSeedAudio() {
  const pieces = [];

  for (const spec of SPECS) {
    try {
      const buffer = await renderSeed(spec);
      const features = analyzeAudioBuffer(buffer);
      if (!features) continue;

      const blob = new Blob([encodeWav(buffer)], { type: 'audio/wav' });

      pieces.push({
        id: spec.id,
        kind: 'audio',
        source: 'seed',
        src: URL.createObjectURL(blob),
        mime: 'audio/wav',
        width: 1,
        height: 1,
        duration: Number(buffer.duration.toFixed(2)),
        features,
      });
    } catch {
      // Si una textura falla, se omite y la obra sigue en silencio.
    }
  }

  return pieces;
}

async function renderSeed(spec) {
  const Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (!Offline) throw new Error('Este navegador no puede renderizar audio offline.');

  const length = Math.round(SAMPLE_RATE * DURATION);
  const ctx = new Offline(1, length, SAMPLE_RATE);
  const rng = makeRng(`pozo-audio-${spec.id}`);

  const out = ctx.createGain();
  out.gain.setValueAtTime(0, 0);
  out.gain.linearRampToValueAtTime(1, EDGE_FADE);
  out.gain.setValueAtTime(1, DURATION - EDGE_FADE);
  out.gain.linearRampToValueAtTime(0, DURATION);
  out.connect(ctx.destination);

  spec.build(ctx, out, rng);

  return ctx.startRendering();
}

// Oscilador con nivel y, opcionalmente, tremolo lento.
function addVoice(ctx, target, { type, frequency, level, detune = 0, tremoloRate = 0, tremoloDepth = 0 }) {
  const osc = ctx.createOscillator();
  osc.type = type;
  osc.frequency.value = frequency;
  osc.detune.value = detune;

  const gain = ctx.createGain();
  gain.gain.value = level;
  osc.connect(gain).connect(target);
  osc.start(0);
  osc.stop(DURATION);

  if (tremoloRate > 0 && tremoloDepth > 0) {
    const mod = ctx.createGain();
    mod.gain.value = level * Math.min(0.6, tremoloDepth);

    const lfo = ctx.createOscillator();
    lfo.frequency.value = tremoloRate;
    lfo.connect(mod).connect(gain.gain);
    lfo.start(0);
    lfo.stop(DURATION);
  }
}

// Ruido determinista: se llena con el PRNG, nunca con Math.random().
function addNoise(ctx, target, rng, level) {
  const buffer = ctx.createBuffer(1, Math.round(SAMPLE_RATE * DURATION), SAMPLE_RATE);
  const data = buffer.getChannelData(0);

  for (let i = 0; i < data.length; i += 1) {
    data[i] = (rng() * 2 - 1) * level;
  }

  const source = ctx.createBufferSource();
  source.buffer = buffer;
  source.connect(target);
  source.start(0);
  return source;
}

function addGrain(ctx, target, { at, frequency, duration, level, type = 'triangle' }) {
  const osc = ctx.createOscillator();
  osc.type = type;
  osc.frequency.value = frequency;

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0, at);
  gain.gain.linearRampToValueAtTime(level, at + 0.006);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);

  osc.connect(gain).connect(target);
  osc.start(at);
  osc.stop(at + duration + 0.04);
}

function addClick(ctx, target, { at, frequency, duration, level, type = 'square' }) {
  const osc = ctx.createOscillator();
  osc.type = type;
  osc.frequency.value = frequency;

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0, at);
  gain.gain.linearRampToValueAtTime(level, at + 0.002);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);

  osc.connect(gain).connect(target);
  osc.start(at);
  osc.stop(at + duration + 0.03);
}

// 1 — Drone: parciales graves con batido lento. Centroide bajo, planitud baja.
function buildDrone(ctx, out, rng) {
  const tone = ctx.createBiquadFilter();
  tone.type = 'lowpass';
  tone.frequency.value = 760;
  tone.Q.value = 0.6;
  tone.connect(out);

  const partials = [
    { ratio: 1, level: 0.16, type: 'sine' },
    { ratio: 1.5, level: 0.09, type: 'sine' },
    { ratio: 2, level: 0.05, type: 'triangle' },
    { ratio: 3.01, level: 0.032, type: 'triangle' },
    { ratio: 4.02, level: 0.02, type: 'sine' },
  ];

  for (const partial of partials) {
    addVoice(ctx, tone, {
      type: partial.type,
      frequency: 54.5 * partial.ratio,
      level: partial.level,
      detune: range(rng, -7, 7),
      tremoloRate: range(rng, 0.03, 0.11),
      tremoloDepth: range(rng, 0.3, 0.55),
    });
  }

  // Sedimento: ruido muy bajo y resonante, sin carácter de aire ni lluvia.
  const sediment = ctx.createBiquadFilter();
  sediment.type = 'bandpass';
  sediment.frequency.value = 1400;
  sediment.Q.value = 9;
  sediment.connect(tone);
  addNoise(ctx, sediment, rng, 0.06);
}

// 2 — Granos: cuerpo grave, resonancia y pings dispersos.
function buildGrains(ctx, out, rng) {
  const body = ctx.createBiquadFilter();
  body.type = 'lowpass';
  body.frequency.value = 2600;
  body.Q.value = 0.5;
  body.connect(out);

  addVoice(ctx, body, { type: 'sine', frequency: 41.2, level: 0.05 });
  addVoice(ctx, body, { type: 'sine', frequency: 82.4, level: 0.022, detune: range(rng, -5, 5) });

  const resonance = ctx.createBiquadFilter();
  resonance.type = 'bandpass';
  resonance.frequency.value = range(rng, 260, 360);
  resonance.Q.value = 16;

  const resonanceGain = ctx.createGain();
  resonanceGain.gain.value = 0.045;
  resonance.connect(resonanceGain).connect(body);
  addNoise(ctx, resonance, rng, 0.5);

  const scale = [220, 277.18, 329.63, 440, 554.37, 659.25, 880];
  const count = int(rng, 22, 30);

  for (let i = 0; i < count; i += 1) {
    addGrain(ctx, body, {
      at: range(rng, 0.25, DURATION - 0.6),
      frequency: pick(rng, scale) * range(rng, 0.995, 1.005),
      duration: range(rng, 0.05, 0.22),
      level: range(rng, 0.035, 0.09),
      type: rng() < 0.3 ? 'sine' : 'triangle',
    });
  }
}

// 3 — Grilla: clicks de datos y portadoras agudas. Centroide y planitud altos.
function buildGrid(ctx, out, rng) {
  const air = ctx.createBiquadFilter();
  air.type = 'highpass';
  air.frequency.value = 420;
  air.Q.value = 0.4;
  air.connect(out);

  addVoice(ctx, air, {
    type: 'triangle',
    frequency: 1318.5,
    level: 0.016,
    tremoloRate: 2.7,
    tremoloDepth: 0.8,
  });

  addVoice(ctx, air, {
    type: 'sine',
    frequency: 987.8,
    level: 0.012,
    tremoloRate: 0.37,
    tremoloDepth: 0.7,
  });

  const clicks = int(rng, 40, 56);
  for (let i = 0; i < clicks; i += 1) {
    addClick(ctx, air, {
      at: range(rng, 0.08, DURATION - 0.3),
      frequency: range(rng, 1800, 4200),
      duration: range(rng, 0.004, 0.014),
      level: range(rng, 0.03, 0.12),
    });
  }

  for (let i = 0; i < 10; i += 1) {
    addClick(ctx, air, {
      at: i * 1.2 + range(rng, 0, 0.15),
      frequency: range(rng, 90, 160),
      duration: 0.03,
      level: 0.05,
      type: 'sine',
    });
  }
}

// WAV PCM 16 bits mono, sin dependencias.
function encodeWav(buffer) {
  const channel = buffer.getChannelData(0);
  const dataSize = channel.length * 2;
  const view = new DataView(new ArrayBuffer(44 + dataSize));

  const writeText = (offset, text) => {
    for (let i = 0; i < text.length; i += 1) {
      view.setUint8(offset + i, text.charCodeAt(i));
    }
  };

  writeText(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeText(8, 'WAVE');
  writeText(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, buffer.sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeText(36, 'data');
  view.setUint32(40, dataSize, true);

  let offset = 44;
  for (let i = 0; i < channel.length; i += 1) {
    const sample = Math.max(-1, Math.min(1, channel[i]));
    view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
    offset += 2;
  }

  return view.buffer;
}
