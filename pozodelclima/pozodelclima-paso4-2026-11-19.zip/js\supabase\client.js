// Cliente de Supabase, cargado solo si hay configuración.
// El SDK llega por CDN con versión fijada: no hay build ni npm.
// La anon key es pública por diseño; la seguridad real vive en RLS.

import { CONFIG } from '../config.js';

// Versión exacta: actualizar a mano y volver a verificar.
const SDK_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.119.1/+esm';

let clientPromise = null;
let clientStatus = { sdk: 'inactivo', error: null };

export function getSupabaseConfig() {
  return {
    url: String(CONFIG.supabase?.url ?? '').trim(),
    anonKey: String(CONFIG.supabase?.anonKey ?? '').trim(),
  };
}

export function isSupabaseConfigured() {
  const { url, anonKey } = getSupabaseConfig();
  if (!url || anonKey.length < 20) return false;

  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' && Boolean(parsed.hostname);
  } catch {
    return false;
  }
}

export function getClientStatus() {
  return { ...clientStatus, configured: isSupabaseConfigured() };
}

// Devuelve el cliente o null. Nunca lanza: la obra puede seguir solo con seed.
export function getSupabase() {
  if (!isSupabaseConfigured()) {
    clientStatus = { sdk: 'inactivo', error: null };
    return Promise.resolve(null);
  }

  if (clientPromise) return clientPromise;

  const { url, anonKey } = getSupabaseConfig();
  clientStatus = { sdk: 'cargando', error: null };

  clientPromise = import(SDK_URL)
    .then(({ createClient }) => {
      const client = createClient(url, anonKey, {
        // La obra no tiene cuentas: no se guardan sesiones ni tokens.
        auth: {
          persistSession: false,
          autoRefreshToken: false,
          detectSessionInUrl: false,
        },
      });

      clientStatus = { sdk: 'listo', error: null };
      return client;
    })
    .catch((error) => {
      const message = error instanceof Error ? error.message : 'no se pudo cargar el SDK';
      clientStatus = { sdk: 'error', error: message };
      clientPromise = null;
      console.warn('[pozo] No se pudo cargar el SDK de Supabase:', message);
      return null;
    });

  return clientPromise;
}
