// Análisis de audio.
// Extrae RMS, centroide espectral, planitud y ZCR, más una envolvente para
// visualizar. No decodifica ni reproduce: recibe un AudioBuffer ya cargado.

import { hslToCss } from './color.js';
import { hannWindow, magnitudeSpectrum, nextPowerOfTwo } from './fft.js';

const FFT_SIZE = 2048;
const MAX_FRAMES = 96;
const WAVEFORM_BUCKETS = 72;
const EPS = 1e-9;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

// Mezcla todos los canales a mono. El análisis espectral no necesita estéreo.
function toMono(buffer) {
  const length = buffer.length;
  const channels = Math.max(1, buffer.numberOfChannels || 1);
  const mono = new Float32Array(length);

  for (let channel = 0; channel < channels; channel += 1) {
    const data = buffer.getChannelData(channel);
    for (let i = 0; i < length; i += 1) {
      mono[i] += data[i] / channels;
    }
  }

  return mono;
}

function buildWaveform(samples) {
  const buckets = Math.min(WAVEFORM_BUCKETS, Math.max(8, Math.floor(samples.length / 64)));
  const waveform = new Array(buckets).fill(0);
  const bucketSize = samples.length / buckets;
  let loudest = 0;

  for (let bucket = 0; bucket < buckets; bucket += 1) {
    const start = Math.floor(bucket * bucketSize);
    const end = Math.min(samples.length, Math.floor((bucket + 1) * bucketSize));
    let sumSquares = 0;
    let count = 0;

    for (let i = start; i < end; i += 1) {
      sumSquares += samples[i] * samples[i];
      count += 1;
    }

    const rms = count > 0 ? Math.sqrt(sumSquares / count) : 0;
    waveform[bucket] = rms;
    if (rms > loudest) loudest = rms;
  }

  // Se normaliza contra el tramo más fuerte: la forma se lee incluso en loops suaves.
  if (loudest <= EPS) return waveform;
  return waveform.map((value) => value / loudest);
}

// Deriva un color estable a partir del espectro. Se usa en el campo y en la lente.
function colorFromSpectrum({ centroidNorm, flatness, rms }) {
  const hue = (188 + centroidNorm * 150) % 360;
  const saturation = clamp(0.28 + flatness * 0.9, 0.18, 0.86);
  const lightness = clamp(0.24 + rms * 1.7, 0.2, 0.72);
  const mean = { h: hue, s: saturation, l: lightness };

  const palette = [
    { h: hue, s: saturation, l: lightness, weight: 0.6 },
    { h: (hue + 38) % 360, s: clamp(saturation * 0.8, 0, 1), l: clamp(lightness * 0.68 + 0.08, 0, 1), weight: 0.25 },
    { h: (hue + 322) % 360, s: clamp(saturation * 0.6 + 0.1, 0.05, 1), l: clamp(lightness * 0.5 + 0.18, 0, 1), weight: 0.15 },
  ].map((color) => ({ ...color, css: hslToCss(color) }));

  return {
    mean,
    brightness: lightness,
    saturation,
    palette,
    dominant: palette[0],
  };
}

// Devuelve features listos para guardar en `pieces` y para la composición.
export function analyzeAudioBuffer(buffer, options = {}) {
  if (!buffer || typeof buffer.getChannelData !== 'function' || buffer.length === 0) {
    return null;
  }

  const sampleRate = buffer.sampleRate || 44100;
  const mono = toMono(buffer);
  const length = mono.length;

  // RMS y pico sobre todo el archivo.
  let sumSquares = 0;
  let peak = 0;
  let crossings = 0;
  let previousSign = 0;

  for (let i = 0; i < length; i += 1) {
    const value = mono[i];
    const magnitude = Math.abs(value);

    sumSquares += value * value;
    if (magnitude > peak) peak = magnitude;

    const sign = value > 0 ? 1 : value < 0 ? -1 : 0;
    if (sign !== 0) {
      if (previousSign !== 0 && sign !== previousSign) crossings += 1;
      previousSign = sign;
    }
  }

  const rms = Math.sqrt(sumSquares / length);
  const zcr = length > 1 ? crossings / (length - 1) : 0;

  // Ventanas repartidas en todo el archivo, no solo al principio.
  const fftSize = Math.min(FFT_SIZE, nextPowerOfTwo(Math.min(length, FFT_SIZE)));
  const window = hannWindow(fftSize);
  const maxStart = Math.max(0, length - fftSize);
  const frames = maxStart === 0
    ? 1
    : Math.min(MAX_FRAMES, Math.max(1, options.maxFrames ?? MAX_FRAMES));
  const hop = frames > 1 ? Math.floor(maxStart / (frames - 1)) : maxStart;

  let centroidSum = 0;
  let flatnessSum = 0;
  let weightSum = 0;

  for (let frame = 0; frame < frames; frame += 1) {
    const start = Math.min(maxStart, frame * hop);
    const slice = mono.subarray(start, start + fftSize);
    const magnitudes = magnitudeSpectrum(slice, fftSize, window);

    let magnitudeSum = 0;
    let weighted = 0;
    let logSum = 0;

    for (let bin = 1; bin < magnitudes.length; bin += 1) {
      const value = magnitudes[bin];
      magnitudeSum += value;
      weighted += value * ((bin * sampleRate) / fftSize);
      logSum += Math.log(value + EPS);
    }

    if (magnitudeSum <= EPS) continue;

    const bins = magnitudes.length - 1;
    const centroid = weighted / magnitudeSum;
    const flatness = Math.exp(logSum / bins) / (magnitudeSum / bins);

    centroidSum += centroid * magnitudeSum;
    flatnessSum += flatness * magnitudeSum;
    weightSum += magnitudeSum;
  }

  const centroid = weightSum > 0 ? centroidSum / weightSum : 0;
  const flatness = weightSum > 0 ? flatnessSum / weightSum : 0;
  const centroidNorm = clamp(centroid / (sampleRate / 2), 0, 1);
  const color = colorFromSpectrum({ centroidNorm, flatness, rms });

  return {
    duration: length / sampleRate,
    sampleRate,
    rms: Number(rms.toFixed(4)),
    peak: Number(peak.toFixed(4)),
    zcr: Number(zcr.toFixed(4)),
    centroid: Number(centroid.toFixed(1)),
    centroidNorm: Number(centroidNorm.toFixed(4)),
    flatness: Number(flatness.toFixed(4)),
    waveform: buildWaveform(mono),
    ...color,
  };
}
