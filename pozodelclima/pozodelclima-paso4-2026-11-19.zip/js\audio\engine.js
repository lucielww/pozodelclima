// Motor de audio.
// Solo reproduce buffers ya existentes (seed o donaciones): no sintetiza nada
// en vivo. Grafo por capa:
//   buffer en loop -> ganancia (fade) -> filtro -> waveshaper opcional -> paneo
//   -> master -> analizador -> salida.
// El clima modula filtro, playbackRate, bitcrush y paneo.

const AudioCtor = window.AudioContext || window.webkitAudioContext;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

// Curva de cuantización suave: más decay, más bitcrush.
function crushCurve(decay) {
  const steps = Math.round(90 - clamp(decay, 0, 1) * 55);
  const size = 1024;
  const curve = new Float32Array(size);

  for (let i = 0; i < size; i += 1) {
    const x = (i / (size - 1)) * 2 - 1;
    curve[i] = Math.round(x * steps) / steps;
  }

  return curve;
}

export function createAudioEngine({ onChange } = {}) {
  const notify = typeof onChange === 'function' ? onChange : () => {};

  let ctx = null;
  let master = null;
  let analyser = null;
  let muted = false;
  let started = false;
  let soloId = null;
  let profile = null;
  let layers = [];
  let generation = 0;

  const buffers = new Map();

  function supported() {
    return Boolean(AudioCtor);
  }

  function ensureContext() {
    if (ctx || !supported()) return ctx;

    try {
      ctx = new AudioCtor();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.9;

      analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.8;

      master.connect(analyser);
      analyser.connect(ctx.destination);
    } catch {
      // Si el navegador bloquea el audio, la obra sigue en silencio.
      ctx = null;
      master = null;
      analyser = null;
    }

    return ctx;
  }

  // Debe llamarse desde el gesto de entrada: iOS no habilita el audio sin eso.
  function unlock() {
    if (!ensureContext()) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    notify();
  }

  function decode(src) {
    if (!buffers.has(src)) {
      const promise = fetch(src)
        .then((response) => {
          if (!response.ok) throw new Error('No se pudo leer el audio.');
          return response.arrayBuffer();
        })
        .then((data) => ctx.decodeAudioData(data))
        .catch((error) => {
          buffers.delete(src);
          throw error;
        });

      buffers.set(src, promise);
    }

    return buffers.get(src);
  }

  function layerLevel(layer, value, seconds) {
    const now = ctx.currentTime;
    const param = layer.gain.gain;

    param.cancelScheduledValues(now);
    param.setValueAtTime(param.value, now);
    param.linearRampToValueAtTime(Math.max(0, value), now + seconds);
  }

  function applySolo(id, seconds = 0.8) {
    for (const layer of layers) {
      const isSolo = layer.id === id;
      const level = isSolo ? Math.min(layer.target * 1.3, 2.2) : layer.target * 0.06;
      layerLevel(layer, level, isSolo ? seconds : seconds * 0.75);
    }
  }

  function buildLayer(item, buffer, index) {
    const piece = item.piece;
    const decay = clamp(profile?.decay ?? 0.4, 0, 1);
    const character = clamp(profile?.audioCharacter ?? 0.4, 0, 1);
    const turbulence = clamp(profile?.turbulence ?? 0.35, 0, 1);

    const rate = clamp(0.85 + character * 0.3 + (index === 0 ? -0.012 : 0.018), 0.85, 1.15);
    const cutoff = clamp(520 + character * 3200 + (1 - decay) * 1200, 380, 6200);
    const fade = clamp(6 + index * 0.9 + turbulence * 2.8, 6, 9.8);

    // Normalización aproximada por RMS y pico: todas las capas suenan parecido.
    // Los audios del seed son muy distintos en nivel; se igualan antes del fade.
    const rms = Math.max(0.005, Number(piece.features?.rms ?? 0.08));
    const peak = Math.max(0.02, Number(piece.features?.peak ?? 0.4));
    let target = clamp(0.03 / rms, 0.1, 2.2);
    target = Math.min(target, 0.6 / peak);
    if (index > 0) target *= 0.78;
    target = clamp(target, 0.08, 2.2);

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.playbackRate.value = rate;

    const gain = ctx.createGain();
    gain.gain.value = 0;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = cutoff;
    filter.Q.value = 0.6;

    const shaper = ctx.createWaveShaper();
    shaper.curve = crushCurve(decay);
    shaper.oversample = '2x';

    const pan = typeof ctx.createStereoPanner === 'function' ? ctx.createStereoPanner() : null;
    const tail = pan ?? master;

    if (pan) {
      pan.pan.value = index === 0 ? -0.28 : 0.28;
      pan.connect(master);
    }

    // En climas limpios el waveshaper se saltea: la textura respira sin costra.
    const useShaper = decay > 0.45;

    source.connect(gain).connect(filter);
    if (useShaper) filter.connect(shaper).connect(tail);
    else filter.connect(tail);

    const now = ctx.currentTime + 0.06;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(target, now + fade);
    source.start(now);

    return { id: piece.id, source, gain, filter, pan, target, rate, cutoff, crush: useShaper };
  }

  async function start(pieces, nextProfile) {
    profile = nextProfile ?? null;

    if (!Array.isArray(pieces) || pieces.length === 0) {
      stopLayers(0.4);
      started = false;
      notify();
      return;
    }

    if (!ensureContext()) {
      started = false;
      notify();
      return;
    }

    const run = ++generation;
    stopLayers(0.35);

    // Nunca más de dos capas simultáneas.
    const list = pieces.slice(0, 2);
    const loaded = await Promise.all(list.map(async (item, index) => {
      try {
        return { item, index, buffer: await decode(item.piece.src) };
      } catch {
        // Un audio que falla se omite; si fallan todos, queda en silencio.
        return null;
      }
    }));

    if (run !== generation) return;

    layers = loaded
      .map((entry) => (entry ? buildLayer(entry.item, entry.buffer, entry.index) : null))
      .filter(Boolean);

    started = layers.length > 0;

    if (started) {
      if (soloId !== null) applySolo(soloId, 0.2);
      if (ctx.state === 'suspended' && document.visibilityState !== 'hidden') {
        ctx.resume().catch(() => {});
      }
    }

    notify();
  }

  function stopLayers(seconds = 0.4) {
    if (!ctx) {
      layers = [];
      return;
    }

    const now = ctx.currentTime;
    for (const layer of layers) {
      try {
        const param = layer.gain.gain;
        param.cancelScheduledValues(now);
        param.setValueAtTime(param.value, now);
        param.linearRampToValueAtTime(0, now + seconds);
        layer.source.stop(now + seconds + 0.06);
      } catch {
        // La capa ya estaba detenida.
      }
    }

    layers = [];
  }

  function setMuted(value) {
    muted = Boolean(value);

    if (ctx) {
      const now = ctx.currentTime;
      const param = master.gain;
      param.cancelScheduledValues(now);
      param.setValueAtTime(param.value, now);
      param.linearRampToValueAtTime(muted ? 0 : 0.9, now + 0.15);
    }

    notify();
    return muted;
  }

  function toggleMute() {
    return setMuted(!muted);
  }

  function solo(id) {
    if (soloId === id) return;
    soloId = id;
    if (ctx && layers.length > 0) applySolo(id, 0.8);
    notify();
  }

  function releaseSolo() {
    if (soloId === null) return;
    soloId = null;
    if (ctx) {
      for (const layer of layers) layerLevel(layer, layer.target, 1.4);
    }
    notify();
  }

  function handleVisibility() {
    const hidden = document.visibilityState === 'hidden';
    document.documentElement.classList.toggle('tab-hidden', hidden);

    if (!ctx) return;

    if (hidden) {
      ctx.suspend().catch(() => {});
    } else if (started) {
      ctx.resume().catch(() => {});
    }

    notify();
    window.setTimeout(notify, 160);
  }

  function getState() {
    let level = 0;

    if (analyser) {
      const data = new Uint8Array(analyser.fftSize);
      analyser.getByteTimeDomainData(data);

      let sumSquares = 0;
      for (let i = 0; i < data.length; i += 1) {
        const value = (data[i] - 128) / 128;
        sumSquares += value * value;
      }

      level = Number(Math.sqrt(sumSquares / data.length).toFixed(3));
    }

    return {
      supported: supported(),
      state: ctx ? ctx.state : 'sin contexto',
      time: ctx ? Number(ctx.currentTime.toFixed(2)) : 0,
      level,
      started,
      muted,
      soloId,
      hidden: document.visibilityState === 'hidden',
      layers: layers.map((layer) => ({
        id: layer.id,
        rate: layer.rate,
        cutoff: layer.cutoff,
        crush: layer.crush,
        target: Number(layer.target.toFixed(3)),
      })),
    };
  }

  function dispose() {
    document.removeEventListener('visibilitychange', handleVisibility);
    stopLayers(0.1);
    if (ctx) ctx.close().catch(() => {});
    ctx = null;
  }

  document.addEventListener('visibilitychange', handleVisibility);

  return {
    supported,
    unlock,
    start,
    stop: stopLayers,
    setMuted,
    toggleMute,
    solo,
    releaseSolo,
    getState,
    dispose,
  };
}
