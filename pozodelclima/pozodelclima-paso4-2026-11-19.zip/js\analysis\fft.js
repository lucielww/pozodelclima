// FFT radix-2 y utilidades espectrales.
// Se usa solo para analizar audio (seed y donaciones), nunca en tiempo real.

const TAU = Math.PI * 2;

const twiddleCache = new Map();
const windowCache = new Map();

export function nextPowerOfTwo(value) {
  let size = 1;
  while (size < value) size <<= 1;
  return size;
}

function twiddles(size) {
  const cached = twiddleCache.get(size);
  if (cached) return cached;

  const half = size >> 1;
  const cos = new Float64Array(half);
  const sin = new Float64Array(half);

  for (let k = 0; k < half; k += 1) {
    const angle = (-TAU * k) / size;
    cos[k] = Math.cos(angle);
    sin[k] = Math.sin(angle);
  }

  const table = { cos, sin };
  twiddleCache.set(size, table);
  return table;
}

// Ventana de Hann cacheada por tamaño.
export function hannWindow(size) {
  const cached = windowCache.get(size);
  if (cached) return cached;

  const window = new Float32Array(size);
  for (let i = 0; i < size; i += 1) {
    window[i] = 0.5 * (1 - Math.cos((TAU * i) / Math.max(1, size - 1)));
  }

  windowCache.set(size, window);
  return window;
}

// Transformada en el lugar. real e imag deben tener largo potencia de dos.
export function fftRadix2(real, imag) {
  const size = real.length;
  if (size <= 1) return;

  // Reordenamiento por inversión de bits.
  for (let i = 1, j = 0; i < size; i += 1) {
    let bit = size >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;

    if (i < j) {
      const realValue = real[i];
      real[i] = real[j];
      real[j] = realValue;

      const imagValue = imag[i];
      imag[i] = imag[j];
      imag[j] = imagValue;
    }
  }

  // Mariposas de Cooley-Tukey.
  for (let width = 2; width <= size; width <<= 1) {
    const half = width >> 1;
    const { cos, sin } = twiddles(width);

    for (let start = 0; start < size; start += width) {
      for (let k = 0; k < half; k += 1) {
        const even = start + k;
        const odd = even + half;
        const oddReal = real[odd];
        const oddImag = imag[odd];
        const rotatedReal = oddReal * cos[k] - oddImag * sin[k];
        const rotatedImag = oddReal * sin[k] + oddImag * cos[k];

        real[odd] = real[even] - rotatedReal;
        imag[odd] = imag[even] - rotatedImag;
        real[even] += rotatedReal;
        imag[even] += rotatedImag;
      }
    }
  }
}

// Magnitudes de la mitad útil del espectro, con ventana opcional.
export function magnitudeSpectrum(samples, size, window) {
  const real = new Float64Array(size);
  const imag = new Float64Array(size);
  const limit = Math.min(size, samples.length);

  for (let i = 0; i < limit; i += 1) {
    real[i] = samples[i] * (window ? window[i] : 1);
  }

  fftRadix2(real, imag);

  const half = size >> 1;
  const magnitudes = new Float32Array(half);
  for (let i = 0; i < half; i += 1) {
    magnitudes[i] = Math.hypot(real[i], imag[i]);
  }

  return magnitudes;
}
