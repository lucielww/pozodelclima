// Análisis de archivos donados.
// Detecta el formato por contenido (no por extensión), decodifica para validar,
// recompone imágenes a WebP/PNG de 1600 px y analiza audio en un worker.
// No guarda ni muestra el nombre original: el flujo solo conserva el blob.

import { analyzeCanvas } from './color.js';
import { analyzeAudioBuffer } from './audio.js';

const IMAGE_MIMES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const AUDIO_MIMES = new Set(['audio/mpeg', 'audio/ogg', 'audio/wav', 'audio/mp4']);
const MAX_PIXELS = 80 * 1000 * 1000;

function fail(code, detail = '') {
  const error = new Error(detail || code);
  error.code = code;
  throw error;
}

// Firma binaria: alcanza con leer los primeros 16 bytes.
export function detectFormat(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length < 12) return null;

  const ascii = (start, length) => {
    let text = '';
    for (let i = start; i < start + length && i < bytes.length; i += 1) {
      text += String.fromCharCode(bytes[i]);
    }
    return text;
  };

  if (bytes[0] === 0x89 && ascii(1, 3) === 'PNG') {
    return { kind: 'image', mime: 'image/png' };
  }

  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return { kind: 'image', mime: 'image/jpeg' };
  }

  if (ascii(0, 4) === 'RIFF' && ascii(8, 4) === 'WEBP') {
    return { kind: 'image', mime: 'image/webp' };
  }

  if (ascii(0, 4) === 'RIFF' && ascii(8, 4) === 'WAVE') {
    return { kind: 'audio', mime: 'audio/wav' };
  }

  if (ascii(0, 4) === 'OggS') {
    return { kind: 'audio', mime: 'audio/ogg' };
  }

  if (ascii(0, 3) === 'ID3' || (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0)) {
    return { kind: 'audio', mime: 'audio/mpeg' };
  }

  if (ascii(4, 4) === 'ftyp') {
    return { kind: 'audio', mime: 'audio/mp4' };
  }

  return null;
}

export function isImageMime(mime) {
  return IMAGE_MIMES.has(mime);
}

export function isAudioMime(mime) {
  return AUDIO_MIMES.has(mime);
}

async function makeBitmap(blob) {
  if (typeof createImageBitmap !== 'function') return null;

  try {
    return await createImageBitmap(blob, { imageOrientation: 'from-image' });
  } catch {
    try {
      return await createImageBitmap(blob);
    } catch {
      return null;
    }
  }
}

// Safari antiguo sin createImageBitmap: se decodifica con <img>. El navegador
// aplica la orientación EXIF al dibujar en canvas.
function makeImageElement(blob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const image = new Image();

    image.onload = () => {
      resolve({
        source: image,
        width: image.naturalWidth,
        height: image.naturalHeight,
        release: () => URL.revokeObjectURL(url),
      });
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('decode'));
    };

    image.src = url;
  });
}

async function loadDrawable(blob) {
  const bitmap = await makeBitmap(blob);

  if (bitmap) {
    return {
      source: bitmap,
      width: bitmap.width,
      height: bitmap.height,
      release: () => bitmap.close?.(),
    };
  }

  try {
    return await makeImageElement(blob);
  } catch {
    fail('decode');
    return null;
  }
}

function canvasToBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => {
    try {
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error('decode'));
      }, type, quality);
    } catch (error) {
      reject(error);
    }
  });
}

// Recompone una imagen: lado mayor 1600, fondo de materia, sin EXIF ni GPS.
export async function processImage(blob, options = {}) {
  const maxSide = Math.max(1, Number(options.maxSide ?? 1600));
  const quality = Math.min(1, Math.max(0.1, Number(options.quality ?? 0.82)));
  const drawable = await loadDrawable(blob);

  try {
    const sourceWidth = Math.max(0, Math.round(drawable.width));
    const sourceHeight = Math.max(0, Math.round(drawable.height));
    if (sourceWidth < 1 || sourceHeight < 1) fail('decode');
    if (sourceWidth * sourceHeight > MAX_PIXELS) fail('pixels');

    const scale = Math.min(1, maxSide / Math.max(sourceWidth, sourceHeight));
    const width = Math.max(1, Math.round(sourceWidth * scale));
    const height = Math.max(1, Math.round(sourceHeight * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) fail('decode');

    // Mismo fondo que el análisis: la transparencia se compone sobre la materia.
    ctx.fillStyle = '#080807';
    ctx.fillRect(0, 0, width, height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(drawable.source, 0, 0, width, height);

    const features = analyzeCanvas(canvas, { k: 4 });
    const out = await canvasToBlob(canvas, 'image/webp', quality);
    const mime = isImageMime(out.type) ? out.type : '';

    if (!mime || !out.size) fail('decode');

    return {
      blob: out,
      mime,
      width,
      height,
      features,
      originalWidth: sourceWidth,
      originalHeight: sourceHeight,
    };
  } finally {
    drawable.release?.();
  }
}

// Decodifica audio sin transcribir. La copia evita que decodeAudioData se quede
// con el buffer original, que después se sube tal cual.
export async function decodeAudio(bytes) {
  const Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (!Offline) fail('decode');

  let context;
  try {
    context = new Offline(1, 1, 44100);
  } catch {
    fail('decode');
  }

  try {
    const buffer = await context.decodeAudioData(bytes.slice(0));
    if (!buffer || !buffer.length) fail('decode');
    return buffer;
  } catch {
    fail('decode');
    return null;
  }
}

let audioWorkerUrl = null;

function workerFeatures(channels, sampleRate, timeoutMs) {
  return new Promise((resolve, reject) => {
    let worker;
    let timer = 0;

    const finish = (callback, value) => {
      if (timer) window.clearTimeout(timer);
      timer = 0;
      try {
        worker?.terminate();
      } catch {
        // Nada que hacer: el worker ya murió.
      }
      callback(value);
    };

    try {
      audioWorkerUrl ??= new URL('./audio-worker.js', import.meta.url);
      worker = new Worker(audioWorkerUrl, { type: 'module' });
    } catch (error) {
      reject(Object.assign(new Error('worker'), { code: 'worker' }));
      return;
    }

    timer = window.setTimeout(() => {
      const error = new Error('timeout');
      error.code = 'timeout';
      finish(reject, error);
    }, timeoutMs);

    worker.onmessage = (event) => {
      const features = event.data?.features;
      if (features) finish(resolve, features);
      else finish(reject, Object.assign(new Error('worker'), { code: 'worker' }));
    };

    worker.onerror = () => {
      finish(reject, Object.assign(new Error('worker'), { code: 'worker' }));
    };

    try {
      worker.postMessage(
        { channels, sampleRate },
        channels.map((channel) => channel.buffer),
      );
    } catch {
      finish(reject, Object.assign(new Error('worker'), { code: 'worker' }));
    }
  });
}

// Analiza en worker para no bloquear la interfaz. Si el worker no está
// disponible, cae al análisis en el hilo principal.
export async function analyzeAudio(buffer, options = {}) {
  const timeoutMs = Math.max(1000, Number(options.timeoutMs ?? 25000));
  const channels = [];

  for (let channel = 0; channel < buffer.numberOfChannels; channel += 1) {
    channels.push(buffer.getChannelData(channel).slice());
  }

  if (channels.length === 0) fail('decode');

  if (typeof Worker !== 'undefined') {
    try {
      return await workerFeatures(channels, buffer.sampleRate, timeoutMs);
    } catch (error) {
      if (error.code === 'timeout') fail('timeout');
    }
  }

  const features = analyzeAudioBuffer(buffer);
  if (!features) fail('decode');
  return features;
}
