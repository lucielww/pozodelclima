// Formulario de contacto.
// En local no se envía nada: la confirmación real solo existe en Netlify.
// El formulario es estático (data-netlify), así que también funciona sin JS.

const form = document.querySelector('#contact-form');
const status = document.querySelector('#contact-status');
const localHosts = new Set(['localhost', '127.0.0.1', '::1', '']);
const SUBMIT_TIMEOUT = 20000;

function setStatus(text, tone = '') {
  if (!status) return;
  status.textContent = text;
  if (tone) status.dataset.tone = tone;
  else delete status.dataset.tone;
}

function isLocal() {
  return location.protocol === 'file:'
    || localHosts.has(location.hostname)
    || location.port === '8000';
}

if (form) {
  form.addEventListener('submit', async (event) => {
    event.preventDefault();

    if (isLocal()) {
      setStatus('El formulario funciona en el deploy de Netlify. En local no se envía nada: así evitamos mandar consultas de prueba.', 'error');
      return;
    }

    const button = form.querySelector('button[type="submit"]');
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), SUBMIT_TIMEOUT);

    if (button) button.disabled = true;
    setStatus('enviando…');

    try {
      const body = new URLSearchParams(new FormData(form)).toString();
      const response = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: controller.signal,
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      form.reset();
      setStatus('mensaje enviado. Si pediste una baja, te respondemos al email que hayas dejado.', 'ok');
    } catch {
      setStatus('No pudimos enviar el mensaje. Probá de nuevo en un rato.', 'error');
    } finally {
      window.clearTimeout(timer);
      if (button) button.disabled = false;
    }
  });
}
