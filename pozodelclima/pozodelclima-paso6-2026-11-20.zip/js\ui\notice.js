// Aviso de donación: los siete puntos obligatorios del plan.
// Se arma como DOM para que el overlay no dependa de HTML duplicado.

export const NOTICE_ITEMS = [
  'La donación es pública y anónima: no lleva tu nombre, tu autoría ni un título.',
  'Puede aparecer en collages futuros de la obra.',
  'Se revisa antes de publicarse: nada entra al pozo automáticamente.',
  'Una vez publicada no se puede retirar.',
  'Doná solo material propio o con licencia libre.',
  'No incluyas rostros, voces ni datos de terceros sin su permiso.',
  'Al donar aceptás CC0: la pieza pasa al dominio público de forma irrevocable.',
];

export const METADATA_NOTE = 'Las imágenes se recomprimen y pierden EXIF y GPS. Los audios se suben sin transformar: pueden conservar metadatos.';

export function buildNotice() {
  const wrapper = document.createElement('div');

  const list = document.createElement('ol');
  list.className = 'donate__notice-list';

  for (const text of NOTICE_ITEMS) {
    const item = document.createElement('li');
    item.textContent = text;
    list.append(item);
  }

  const meta = document.createElement('p');
  meta.className = 'donate__notice-meta';
  meta.textContent = METADATA_NOTE;

  wrapper.append(list, meta);
  return wrapper;
}
