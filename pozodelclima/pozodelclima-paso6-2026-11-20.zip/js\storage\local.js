// Registro local de las donaciones hechas desde este navegador.
// Guarda { id, path, at } bajo `pozo.donations` para excluir las piezas propias
// de la composición y contar la cuota de 3 donaciones por 24 h.
// Los envíos que subieron el archivo pero no pudieron registrar la fila quedan
// en `pozo.orphans` para diagnóstico y limpieza manual. Sin datos personales.

const STORAGE_KEY = 'pozo.donations';
const ORPHAN_KEY = 'pozo.orphans';
const MAX_RECORDS = 50;
const MAX_ORPHANS = 20;

function readList(key) {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    // Modo privado, cuota llena o JSON roto: la obra sigue sin registro.
    return [];
  }
}

function writeList(key, list) {
  try {
    window.localStorage.setItem(key, JSON.stringify(list));
  } catch {
    // Si no se puede guardar, la donación igual sigue su curso.
  }
}

function isRecord(value) {
  return Boolean(value)
    && typeof value === 'object'
    && typeof value.id === 'string'
    && value.id.length > 0;
}

function timestamp(value) {
  const time = Date.parse(typeof value === 'string' ? value : '');
  return Number.isFinite(time) ? time : 0;
}

export function getDonations() {
  return readList(STORAGE_KEY)
    .filter(isRecord)
    .slice(-MAX_RECORDS)
    .map((record) => ({
      id: record.id,
      path: typeof record.path === 'string' ? record.path : '',
      at: typeof record.at === 'string' ? record.at : '',
    }));
}

export function getOwnIds() {
  return [...new Set(getDonations().map((record) => record.id))];
}

export function addDonation(record) {
  if (!isRecord(record)) return getDonations();

  const donations = getDonations().filter((entry) => entry.id !== record.id);
  donations.push({
    id: record.id,
    path: typeof record.path === 'string' ? record.path : '',
    at: typeof record.at === 'string' ? record.at : new Date().toISOString(),
  });

  const trimmed = donations.slice(-MAX_RECORDS);
  writeList(STORAGE_KEY, trimmed);
  return trimmed;
}

// Cuota móvil de 24 h. Solo cuentan las donaciones registradas con éxito.
export function getQuota(options = {}) {
  const limit = Math.max(1, Number(options.limit ?? 3));
  const windowMs = Math.max(1000, Number(options.windowMs ?? 24 * 60 * 60 * 1000));
  const now = Number.isFinite(Number(options.now)) ? Number(options.now) : Date.now();

  const recent = getDonations()
    .map((record) => timestamp(record.at))
    .filter((time) => time > 0 && time <= now && now - time < windowMs)
    .sort((a, b) => a - b);

  const used = recent.length;
  return {
    used,
    limit,
    remaining: Math.max(0, limit - used),
    resetAt: used > 0 ? recent[0] + windowMs : 0,
  };
}

// Objetos que quedaron en Storage sin fila (o con estado incierto).
export function getOrphans() {
  return readList(ORPHAN_KEY)
    .filter(isRecord)
    .slice(-MAX_ORPHANS)
    .map((record) => ({
      id: record.id,
      path: typeof record.path === 'string' ? record.path : '',
      at: typeof record.at === 'string' ? record.at : '',
      stage: typeof record.stage === 'string' ? record.stage : '',
      code: typeof record.code === 'string' ? record.code : '',
    }));
}

export function addOrphan(record) {
  if (!isRecord(record)) return getOrphans();

  const orphans = getOrphans().filter((entry) => entry.id !== record.id);
  orphans.push({
    id: record.id,
    path: typeof record.path === 'string' ? record.path : '',
    at: typeof record.at === 'string' ? record.at : new Date().toISOString(),
    stage: typeof record.stage === 'string' ? record.stage : '',
    code: typeof record.code === 'string' ? record.code : '',
  });

  const trimmed = orphans.slice(-MAX_ORPHANS);
  writeList(ORPHAN_KEY, trimmed);
  return trimmed;
}
