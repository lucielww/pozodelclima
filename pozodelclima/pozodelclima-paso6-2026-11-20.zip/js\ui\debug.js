// Panel de desarrollo para ?debug=1.
// Muestra el perfil, la fuente y la selección. Nunca aparece sin el parámetro.

function fixed(value, digits = 2) {
  return Number(value ?? 0).toFixed(digits);
}

function shortId(value) {
  const id = String(value ?? '');
  return id.length > 18 ? `${id.slice(0, 8)}…${id.slice(-4)}` : id;
}

function audioStatus(state) {
  const labels = {
    running: 'activo',
    suspended: 'pausado',
    closed: 'cerrado',
  };
  return labels[state] ?? state;
}

export function initDebug() {
  const panel = document.createElement('aside');
  panel.className = 'debug-panel';
  panel.setAttribute('aria-label', 'datos de desarrollo');
  panel.hidden = true;

  const title = document.createElement('p');
  title.className = 'debug-panel__title';
  title.textContent = 'debug · clima interno';

  const body = document.createElement('pre');
  body.className = 'debug-panel__body';

  panel.append(title, body);
  document.body.append(panel);

  return function updateDebug(state, meta, audioState) {
    const profile = state.profile;
    if (!profile) return;

    panel.hidden = false;

    const audioMeta = state.audioMeta;
    const remote = state.remoteStatus;
    const remoteError = remote?.error ? remote.error.slice(0, 64) : '';
    const remoteMinutes = remote?.expiresAt
      ? Math.max(0, Math.round((remote.expiresAt - Date.now()) / 60000))
      : null;
    const remoteDetail = remoteError
      ? `error: ${remoteError}`
      : remoteMinutes !== null
        ? `urls vencen en ${remoteMinutes} min`
        : 'sin urls';

    const donation = state.donation;
    const donationQuota = donation?.quota;
    const donationDetail = donation?.error
      ? `${donation.error}${donation.detail ? ` [${donation.detail.slice(0, 48)}]` : ''}`
      : donation?.stage ?? 'inactivo';
    const donationLine = `donación    ${donationDetail}${donation?.hash ? ` · sha ${donation.hash.slice(0, 12)}…` : ''}${donation?.id ? ` · id ${shortId(donation.id)}` : ''}${donationQuota ? ` · cuota ${donationQuota.used}/${donationQuota.limit}` : ''}${donation?.orphans ? ` · huérfanas ${donation.orphans}` : ''}`;

    const lines = [
      `estado      ${profile.state}`,
      `fuente      ${[state.weatherSource, state.locationSource].filter(Boolean).filter((value, index, all) => all.indexOf(value) === index).join(' · ') || '—'}`,
      `supabase    ${remote ? `${remote.state} · ${remote.approved} aprobadas · ${remote.signed} con url` : '—'}`,
      `remoto      ${remoteDetail} · sdk ${remote?.client?.sdk ?? '—'} · propias ${state.ownIds?.length ?? 0}`,
      donationLine,
      `perfil      H ${fixed(profile.hue, 1)} · S ${fixed(profile.saturation)} · L ${fixed(profile.lightness)}`,
      `            dens ${fixed(profile.density)} · turb ${fixed(profile.turbulence)} · decay ${fixed(profile.decay)}`,
      `            heat ${fixed(profile.heat)} · night ${profile.night ? 'sí' : 'no'} · audio ${fixed(profile.audioCharacter)}`,
      `selección   ${meta?.count ?? state.selected.length}/${meta?.desired ?? '—'} · afinidad ${meta?.affinityCount ?? '—'} · contraste ${meta?.contrastCount ?? '—'}`,
      `audio sel   ${audioMeta ? `${audioMeta.count}/${audioMeta.poolSize} · umbral ${fixed(audioMeta.threshold)}` : '—'}`,
      `audio       ${audioState ? `${audioStatus(audioState.state)} · ${audioState.time.toFixed(1)}s · nivel ${fixed(audioState.level, 3)} · ${audioState.muted ? 'mute' : 'sonando'} · ${audioState.layers.length} ${audioState.layers.length === 1 ? 'capa' : 'capas'} · ${audioState.soloId ? 'lente' : 'mezcla'}` : 'sin contexto'}`,
      `modo        buffers (sin síntesis en vivo) · pestaña ${audioState?.hidden ? 'oculta' : 'visible'}`,
      `campo       ${window.innerWidth}×${window.innerHeight} · ${window.innerWidth < 720 ? 'móvil' : 'desktop'}`,
      `sesión      ${state.sessionId}`,
      '',
      'piezas',
    ];

    for (const item of state.selected) {
      const features = item.piece.features ?? {};
      lines.push(
        `${shortId(item.piece.id).padEnd(16)} d ${fixed(item.distance, 3)}  ${item.group.slice(0, 4).padEnd(4)}  H ${fixed(features.mean?.h, 0)}  B ${fixed(features.brightness)}  S ${fixed(features.saturation)}  ${item.piece.source === 'supabase' ? 'red' : 'seed'}`,
      );
    }

    if (audioState?.layers.length) {
      lines.push('', 'capas');
      for (const layer of audioState.layers) {
        lines.push(
          `${shortId(layer.id).padEnd(16)} rate ${fixed(layer.rate)}  filtro ${Math.round(layer.cutoff)} Hz  crush ${layer.crush ? 'sí' : 'no'}  vol ${fixed(layer.target, 3)}`,
        );
      }
    }

    if (state.audioSelected?.length) {
      lines.push('', 'features de audio');
      for (const item of state.audioSelected) {
        const features = item.piece.features ?? {};
        lines.push(
          `${shortId(item.piece.id).padEnd(16)} C ${fixed(features.centroidNorm)}  F ${fixed(features.flatness)}  RMS ${fixed(features.rms)}  ZCR ${fixed(features.zcr)}`,
        );
      }
    }

    body.textContent = lines.join('\n');
  };
}
