// Filtros SVG de fermentación.
// feTurbulence + feDisplacementMap deforman apenas la materia: no son un efecto
// decorativo encima, son la costra del archivo. Se aplican a pocas piezas y
// nunca a todas, para que el campo no se convierta en una vidriera de filtros.
// El ruido de fondo es un segundo filtro, estático, sobre una capa aparte.

const NS = 'http://www.w3.org/2000/svg';

const FERMENTS = [
  { id: 'pozo-ferment-a', freq: '0.012 0.016', octaves: 2, seed: 11, scale: 7 },
  { id: 'pozo-ferment-b', freq: '0.021 0.017', octaves: 3, seed: 29, scale: 4 },
  { id: 'pozo-ferment-c', freq: '0.007 0.011', octaves: 2, seed: 47, scale: 10 },
];

export const FERMENT_LIMIT = 5;

let installed = false;

function addFilter(svg, spec) {
  const filter = document.createElementNS(NS, 'filter');
  filter.setAttribute('id', spec.id);
  filter.setAttribute('x', '-10%');
  filter.setAttribute('y', '-10%');
  filter.setAttribute('width', '120%');
  filter.setAttribute('height', '120%');
  filter.setAttribute('color-interpolation-filters', 'sRGB');

  const turbulence = document.createElementNS(NS, 'feTurbulence');
  turbulence.setAttribute('type', 'fractalNoise');
  turbulence.setAttribute('baseFrequency', spec.freq);
  turbulence.setAttribute('numOctaves', String(spec.octaves));
  turbulence.setAttribute('seed', String(spec.seed));
  turbulence.setAttribute('stitchTiles', 'stitch');
  turbulence.setAttribute('result', 'turbulencia');

  const displacement = document.createElementNS(NS, 'feDisplacementMap');
  displacement.setAttribute('in', 'SourceGraphic');
  displacement.setAttribute('in2', 'turbulencia');
  displacement.setAttribute('scale', String(spec.scale));
  displacement.setAttribute('xChannelSelector', 'R');
  displacement.setAttribute('yChannelSelector', 'G');

  filter.append(turbulence, displacement);
  svg.append(filter);
}

function addGrain(svg) {
  const filter = document.createElementNS(NS, 'filter');
  filter.setAttribute('id', 'pozo-grain');
  filter.setAttribute('x', '0');
  filter.setAttribute('y', '0');
  filter.setAttribute('width', '100%');
  filter.setAttribute('height', '100%');
  filter.setAttribute('color-interpolation-filters', 'sRGB');

  const turbulence = document.createElementNS(NS, 'feTurbulence');
  turbulence.setAttribute('type', 'fractalNoise');
  turbulence.setAttribute('baseFrequency', '0.82');
  turbulence.setAttribute('numOctaves', '3');
  turbulence.setAttribute('seed', '7');
  turbulence.setAttribute('stitchTiles', 'stitch');

  const gray = document.createElementNS(NS, 'feColorMatrix');
  gray.setAttribute('type', 'saturate');
  gray.setAttribute('values', '0');

  const alpha = document.createElementNS(NS, 'feComponentTransfer');
  const func = document.createElementNS(NS, 'feFuncA');
  func.setAttribute('type', 'linear');
  func.setAttribute('slope', '0.55');
  alpha.append(func);

  filter.append(turbulence, gray, alpha);
  svg.append(filter);
}

export function filtersSupported() {
  if (typeof CSS === 'undefined' || typeof CSS.supports !== 'function') return false;
  return CSS.supports('filter', 'url(#pozo-ferment-a)');
}

// Instala defs y la capa de grano una sola vez por documento.
// La capa vive fuera del stage para sobrevivir a cada repintado del campo.
export function initSvgFilters({ grain = true } = {}) {
  if (installed) return;

  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'pozo-filters');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.style.position = 'absolute';
  svg.style.width = '0';
  svg.style.height = '0';
  svg.style.overflow = 'hidden';

  const defs = document.createElementNS(NS, 'defs');
  FERMENTS.forEach((spec) => addFilter(defs, spec));
  addGrain(defs);
  svg.append(defs);
  document.body.append(svg);

  if (grain && filtersSupported()) {
    const noise = document.createElement('div');
    noise.className = 'stage-noise';
    noise.setAttribute('aria-hidden', 'true');
    document.body.append(noise);
  }

  installed = true;
}

// Devuelve un filtro para una pieza o null. La decisión es determinista: el
// mismo campo muestra la misma costra en cada repintado.
export function pickFerment(rng, { allowed = true } = {}) {
  if (!allowed || !filtersSupported()) return null;

  const chance = rng();
  if (chance > 0.34) return null;

  return FERMENTS[Math.floor(rng() * FERMENTS.length) % FERMENTS.length].id;
}
