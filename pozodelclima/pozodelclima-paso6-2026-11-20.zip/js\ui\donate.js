// Overlay de donación.
// Aviso, checkbox, elección de archivo, análisis, subida y comprobante.
// No toca la composición actual: la donación solo puede aparecer en otra visita.

import { CONFIG } from '../config.js';
import { getOrphans, getQuota } from '../storage/local.js';
import { donate } from '../upload/donate.js';
import { DonationError } from '../upload/process.js';
import { buildNotice } from './notice.js';

const FOCUSABLE = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
const ACCEPT = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'audio/mpeg',
  'audio/ogg',
  'audio/wav',
  'audio/mp4',
  '.jpg',
  '.jpeg',
  '.png',
  '.webp',
  '.mp3',
  '.ogg',
  '.wav',
  '.m4a',
].join(',');

function quotaOptions() {
  const config = CONFIG.donation ?? {};
  return {
    limit: config.dailyQuota ?? 3,
    windowMs: config.windowMs ?? 24 * 60 * 60 * 1000,
  };
}

function formatBytes(bytes) {
  const size = Math.max(0, Number(bytes) || 0);
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
  return `${(size / (1024 * 1024)).toFixed(1).replace('.', ',')} MB`;
}

export function initDonate(options = {}) {
  const { stage, state, getKnownHashes, onChange = () => {}, extraInert = [] } = options;
  if (!state) throw new Error('Falta el estado para la donación.');

  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = 'donate-trigger';
  trigger.hidden = true;
  trigger.textContent = '＋';
  trigger.setAttribute('aria-label', 'donar un archivo a la obra');
  trigger.setAttribute('title', 'donar un archivo');
  document.body.append(trigger);

  const overlay = document.createElement('section');
  overlay.className = 'donate';
  overlay.hidden = true;
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-labelledby', 'donate-title');
  overlay.setAttribute('aria-hidden', 'true');

  overlay.innerHTML = `
    <div class="donate__panel" tabindex="-1">
      <button class="donate__close" type="button" data-donate-close aria-label="cerrar donación">×</button>
      <p class="donate__kicker">donación</p>
      <h2 id="donate-title" class="donate__title">donar materia</h2>
      <p class="donate__intro">Elegí una imagen o un audio. Se analiza en tu navegador y queda pendiente de revisión; nada se publica automáticamente. No guardamos tu nombre, tu ubicación ni el nombre del archivo.</p>
      <div class="donate__notice" data-donate-notice></div>
      <div class="donate__form" data-donate-form>
        <label class="donate__check">
          <input type="checkbox" data-donate-accept>
          <span>leí el aviso y acepto donar bajo CC0.</span>
        </label>
        <div class="donate__pick">
          <input class="donate__file" type="file" id="donate-file" accept="${ACCEPT}" data-donate-file>
          <label class="button donate__file-label" for="donate-file" data-donate-file-label>elegir archivo</label>
          <span class="donate__file-summary" data-donate-summary>imagen hasta 8 MB · audio hasta 12 MB y 90 s</span>
        </div>
        <button class="button button--primary donate__submit" type="button" data-donate-submit disabled>enviar donación</button>
        <p class="donate__quota" data-donate-quota></p>
      </div>
      <div class="donate__receipt" data-donate-receipt hidden>
        <p class="donate__receipt-title">quedó pendiente de revisión</p>
        <p class="donate__receipt-text">No cambia esta visita. Si se aprueba, puede aparecer en una próxima entrada.</p>
        <p class="donate__receipt-text">Guardá el comprobante por si necesitás pedir una baja:</p>
        <code class="donate__id" data-donate-id></code>
        <div class="donate__receipt-actions">
          <button class="button" type="button" data-donate-copy>copiar comprobante</button>
          <button class="button" type="button" data-donate-close>cerrar</button>
        </div>
      </div>
      <p class="donate__status" role="status" aria-live="polite" data-donate-status></p>
      <p class="donate__foot">¿te equivocaste? <a href="contacto.html">pedí una baja</a> con el comprobante.</p>
    </div>
  `;

  document.body.append(overlay);

  const panel = overlay.querySelector('.donate__panel');
  const notice = overlay.querySelector('[data-donate-notice]');
  const form = overlay.querySelector('[data-donate-form]');
  const receipt = overlay.querySelector('[data-donate-receipt]');
  const receiptId = overlay.querySelector('[data-donate-id]');
  const acceptInput = overlay.querySelector('[data-donate-accept]');
  const fileInput = overlay.querySelector('[data-donate-file]');
  const fileLabel = overlay.querySelector('[data-donate-file-label]');
  const summary = overlay.querySelector('[data-donate-summary]');
  const submit = overlay.querySelector('[data-donate-submit]');
  const quotaText = overlay.querySelector('[data-donate-quota]');
  const status = overlay.querySelector('[data-donate-status]');
  const copyButton = overlay.querySelector('[data-donate-copy]');
  const closeButtons = overlay.querySelectorAll('[data-donate-close]');

  notice.append(buildNotice());

  const inertNodes = [stage, ...extraInert].filter((node) => node && typeof node === 'object');
  let previousInert = [];
  let lastFocus = null;
  let file = null;
  let busy = false;
  let receiptCode = '';
  let quotaNow = getQuota(quotaOptions());

  function readQuota() {
    quotaNow = getQuota(quotaOptions());
    return quotaNow;
  }

  function updateQuota() {
    const { used, limit, remaining } = quotaNow;
    quotaText.textContent = remaining > 0
      ? `donaciones en 24 h: ${used}/${limit} · te quedan ${remaining}.`
      : `donaciones en 24 h: ${used}/${limit} · alcanzaste el límite.`;
    quotaText.dataset.tone = remaining > 0 ? '' : 'warn';
  }

  function setStatus(text, tone = '') {
    status.textContent = text;
    if (tone) status.dataset.tone = tone;
    else delete status.dataset.tone;
  }

  function setState(patch) {
    Object.assign(state.donation, patch, {
      at: Date.now(),
      orphans: getOrphans().length,
    });
    onChange();
  }

  function updateSubmit() {
    const full = quotaNow.remaining <= 0;
    submit.disabled = busy || full || !file || !acceptInput.checked || !receipt.hidden;
  }

  function applyQuota() {
    const full = quotaNow.remaining <= 0;
    fileInput.disabled = full;
    acceptInput.disabled = full;
    fileLabel.classList.toggle('donate__file-label--off', full);
    updateQuota();
    updateSubmit();
  }

  function setInert(on) {
    if (on) {
      previousInert = inertNodes.map((node) => Boolean(node.inert));
      for (const node of inertNodes) node.inert = true;
      trigger.inert = true;
    } else {
      inertNodes.forEach((node, index) => {
        node.inert = previousInert[index] ?? false;
      });
      trigger.inert = false;
    }
  }

  function resetForm() {
    file = null;
    receiptCode = '';
    busy = false;
    acceptInput.checked = false;
    fileInput.value = '';
    fileInput.disabled = false;
    acceptInput.disabled = false;
    fileLabel.classList.remove('donate__file-label--off');
    summary.textContent = 'imagen hasta 8 MB · audio hasta 12 MB y 90 s';
    form.hidden = false;
    receipt.hidden = true;
    receiptId.textContent = '';
    overlay.removeAttribute('aria-busy');
    setStatus('');
    readQuota();
    applyQuota();
    updateSubmit();
  }

  function open() {
    if (!overlay.hidden) return;

    lastFocus = document.activeElement;
    resetForm();

    const full = quotaNow.remaining <= 0;
    setStatus(
      full ? 'alcanzaste el límite de donaciones en 24 h. Volvé más tarde.' : '',
      full ? 'warn' : '',
    );

    overlay.hidden = false;
    overlay.setAttribute('aria-hidden', 'false');
    document.body.classList.add('donate-open');
    setInert(true);
    closeButtons[0]?.focus({ preventScroll: true });

    setState({ stage: 'aviso', error: null, detail: '', hash: '', id: '', quota: quotaNow });
  }

  function close() {
    if (overlay.hidden) return;

    if (busy) {
      setStatus('esperá a que termine la donación.', 'warn');
      return;
    }

    trigger.inert = false;

    if (lastFocus instanceof HTMLElement && lastFocus.isConnected) {
      lastFocus.focus({ preventScroll: true });
    }

    if (overlay.contains(document.activeElement)) {
      document.activeElement.blur();
    }

    overlay.hidden = true;
    overlay.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('donate-open');
    setInert(false);

    setState({ stage: receiptCode ? 'lista' : 'inactivo', quota: quotaNow });
  }

  function chooseFile(nextFile) {
    file = nextFile ?? null;
    summary.textContent = file
      ? `archivo elegido · ${formatBytes(file.size)}`
      : 'imagen hasta 8 MB · audio hasta 12 MB y 90 s';
    setStatus('');
    updateSubmit();
  }

  function handleStage(next) {
    const labels = {
      analizando: 'analizando archivo…',
      subiendo: 'subiendo archivo…',
      registrando: 'registrando donación…',
      lista: 'donación recibida.',
    };

    if (labels[next]) setStatus(labels[next], next === 'lista' ? 'ok' : '');
    setState({ stage: next, quota: quotaNow });
  }

  async function submitDonation() {
    if (busy) return;

    if (!acceptInput.checked) {
      setStatus('Aceptá el aviso para continuar.', 'warn');
      acceptInput.focus();
      return;
    }

    if (!file) {
      setStatus('Elegí un archivo para donar.', 'warn');
      fileInput.focus();
      return;
    }

    readQuota();
    if (quotaNow.remaining <= 0) {
      applyQuota();
      setStatus('Alcanzaste el límite de donaciones en 24 h.', 'warn');
      return;
    }

    busy = true;
    overlay.setAttribute('aria-busy', 'true');
    submit.disabled = true;
    fileInput.disabled = true;
    acceptInput.disabled = true;
    setStatus('analizando archivo…');
    setState({
      stage: 'analizando',
      hash: '',
      id: '',
      error: null,
      detail: '',
      quota: quotaNow,
    });

    try {
      const known = getKnownHashes?.();
      const result = await donate({
        file,
        accepted: true,
        knownHashes: known instanceof Set ? known : new Set(),
        onStage: handleStage,
      });

      receiptCode = result.id;
      quotaNow = result.quota;
      updateQuota();

      form.hidden = true;
      receipt.hidden = false;
      receiptId.textContent = result.id;
      setStatus('donación recibida.', 'ok');
      setState({
        stage: 'lista',
        hash: result.sha256,
        id: result.id,
        error: null,
        detail: '',
        quota: quotaNow,
      });
      copyButton.focus({ preventScroll: true });
    } catch (error) {
      const failure = error instanceof DonationError
        ? error
        : new DonationError('internal', undefined, String(error));

      setStatus(failure.message, 'error');
      setState({
        stage: 'error',
        hash: '',
        id: '',
        error: failure.message,
        detail: failure.detail,
        quota: readQuota(),
      });

      if (failure.code === 'quota') applyQuota();
    } finally {
      busy = false;
      overlay.removeAttribute('aria-busy');
      if (!form.hidden) applyQuota();
      updateSubmit();
      onChange();
    }
  }

  async function copyReceipt() {
    if (!receiptCode) return;

    try {
      await navigator.clipboard.writeText(receiptCode);
      setStatus('comprobante copiado.', 'ok');
    } catch {
      const range = document.createRange();
      range.selectNodeContents(receiptId);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      setStatus('comprobante seleccionado: copialo a mano.', 'warn');
    }
  }

  trigger.addEventListener('click', open);
  closeButtons.forEach((button) => button.addEventListener('click', close));
  acceptInput.addEventListener('change', updateSubmit);
  fileInput.addEventListener('change', () => chooseFile(fileInput.files?.[0] ?? null));
  submit.addEventListener('click', submitDonation);
  copyButton.addEventListener('click', copyReceipt);

  overlay.addEventListener('click', (event) => {
    if (event.target === overlay) close();
  });

  document.addEventListener('keydown', (event) => {
    if (overlay.hidden) return;

    if (event.key === 'Escape') {
      event.preventDefault();
      close();
      return;
    }

    if (event.key !== 'Tab') return;

    const focusable = Array.from(panel.querySelectorAll(FOCUSABLE)).filter((node) => {
      return !node.disabled && node.offsetParent !== null;
    });

    if (focusable.length === 0) {
      event.preventDefault();
      panel.focus();
      return;
    }

    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (!overlay.contains(document.activeElement)) {
      event.preventDefault();
      first.focus();
    } else if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  // Estado inicial para el panel de debug, aunque todavía no se haya abierto.
  state.donation.quota = quotaNow;
  state.donation.orphans = getOrphans().length;
  onChange();

  return {
    show() {
      trigger.hidden = false;
    },
    open,
    close,
  };
}
