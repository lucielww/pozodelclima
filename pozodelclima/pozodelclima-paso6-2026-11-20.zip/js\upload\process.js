// Procesamiento de una donación antes de subirla.
// Valida por contenido, analiza, comprime imágenes, calcula SHA-256 y rechaza
// duplicados. No conserva ni devuelve el nombre original del archivo.

import { CONFIG } from '../config.js';
import {
  analyzeAudio,
  decodeAudio,
  detectFormat,
  isAudioMime,
  isImageMime,
  processImage,
} from '../analysis/file.js';

const MESSAGES = {
  type: 'Ese formato no se puede donar. Probá con JPEG, PNG, WebP, MP3, OGG, WAV o M4A.',
  size: 'El archivo supera el límite: 8 MB para imágenes y 12 MB para audios.',
  pixels: 'La imagen es demasiado grande para procesarla.',
  duration: 'El audio dura más de 90 segundos.',
  decode: 'No pudimos leer el archivo. Puede estar dañado o no ser válido.',
  duplicate: 'Ese archivo ya está en el pozo.',
  timeout: 'La operación tardó demasiado. Probá de nuevo.',
  crypto: 'Este navegador no puede verificar el archivo.',
  quota: 'Ya donaste 3 archivos en las últimas 24 h. Probá de nuevo más tarde.',
  notice: 'Aceptá el aviso para continuar.',
  config: 'La donación no está disponible ahora. La obra sigue funcionando.',
  upload: 'No pudimos subir el archivo. Revisá la conexión y probá de nuevo.',
  server: 'No pudimos registrar la donación. El archivo no se publicó.',
  internal: 'Algo falló al procesar la donación. Probá de nuevo.',
};

export class DonationError extends Error {
  constructor(code, message = MESSAGES[code] ?? MESSAGES.internal, detail = '') {
    super(message);
    this.name = 'DonationError';
    this.code = code;
    this.detail = String(detail ?? '').replace(/\s+/g, ' ').trim().slice(0, 180);
  }
}

export function donationMessage(code) {
  return MESSAGES[code] ?? MESSAGES.internal;
}

export function toDonationError(error, fallback = 'internal') {
  if (error instanceof DonationError) return error;

  const code = typeof error?.code === 'string' && MESSAGES[error.code] ? error.code : fallback;
  return new DonationError(code, MESSAGES[code], error?.message ?? '');
}

function withTimeout(promise, timeoutMs, code) {
  let timer = 0;

  const expired = new Promise((_, reject) => {
    timer = window.setTimeout(() => {
      reject(new DonationError(code, MESSAGES[code]));
    }, Math.max(1000, Number(timeoutMs) || 10000));
  });

  return Promise.race([promise, expired])
    .finally(() => window.clearTimeout(timer));
}

const EXTENSIONS = {
  'image/png': 'png',
  'image/webp': 'webp',
  'audio/mpeg': 'mp3',
  'audio/ogg': 'ogg',
  'audio/wav': 'wav',
  'audio/mp4': 'm4a',
};

export function extensionFor(mime) {
  return EXTENSIONS[mime] ?? '';
}

export async function sha256Hex(blob) {
  if (!window.crypto?.subtle || typeof blob?.arrayBuffer !== 'function') {
    throw new DonationError('crypto');
  }

  const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
  return [...new Uint8Array(digest)]
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('');
}

function limits() {
  return CONFIG.donation ?? {};
}

// Devuelve el material listo para Storage y la fila `pending`.
export async function processFile(file, options = {}) {
  const config = limits();
  const knownHashes = options.knownHashes instanceof Set ? options.knownHashes : new Set();

  if (!file || typeof file.arrayBuffer !== 'function' || !file.size) {
    throw new DonationError('decode');
  }

  let bytes;
  try {
    bytes = await withTimeout(file.arrayBuffer(), config.analysisTimeoutMs ?? 25000, 'timeout');
  } catch (error) {
    throw toDonationError(error, 'decode');
  }

  if (!bytes || bytes.byteLength === 0) throw new DonationError('decode');

  const format = detectFormat(new Uint8Array(bytes.slice(0, 16)));
  if (!format || (!isImageMime(format.mime) && !isAudioMime(format.mime))) {
    throw new DonationError('type');
  }

  if (format.kind === 'image') {
    if (bytes.byteLength > (config.imageMaxBytes ?? 8 * 1024 * 1024)) {
      throw new DonationError('size');
    }

    const source = new Blob([bytes], { type: format.mime });
    let image;

    try {
      image = await withTimeout(
        processImage(source, {
          maxSide: config.imageMaxSide ?? 1600,
          quality: config.imageQuality ?? 0.82,
        }),
        config.analysisTimeoutMs ?? 25000,
        'timeout',
      );
    } catch (error) {
      throw toDonationError(error, 'decode');
    }

    if (!image?.blob?.size) throw new DonationError('decode');
    if (image.blob.size > (config.imageMaxBytes ?? 8 * 1024 * 1024)) {
      throw new DonationError('size');
    }

    const sha256 = await sha256Hex(image.blob);
    if (knownHashes.has(sha256)) throw new DonationError('duplicate');

    return {
      kind: 'image',
      blob: image.blob,
      mime: image.mime,
      ext: extensionFor(image.mime),
      bytes: image.blob.size,
      originalBytes: bytes.byteLength,
      width: image.width,
      height: image.height,
      durationMs: null,
      features: image.features,
      sha256,
    };
  }

  if (bytes.byteLength > (config.audioMaxBytes ?? 12 * 1024 * 1024)) {
    throw new DonationError('size');
  }

  let buffer;
  try {
    buffer = await withTimeout(
      decodeAudio(bytes),
      config.analysisTimeoutMs ?? 25000,
      'timeout',
    );
  } catch (error) {
    throw toDonationError(error, 'decode');
  }

  if (buffer.duration > (config.audioMaxSeconds ?? 90)) {
    throw new DonationError('duration');
  }

  let features;
  try {
    features = await analyzeAudio(buffer, {
      timeoutMs: config.analysisTimeoutMs ?? 25000,
    });
  } catch (error) {
    throw toDonationError(error, 'decode');
  }

  if (!features) throw new DonationError('decode');

  const blob = new Blob([bytes], { type: format.mime });
  const sha256 = await sha256Hex(blob);
  if (knownHashes.has(sha256)) throw new DonationError('duplicate');

  return {
    kind: 'audio',
    blob,
    mime: format.mime,
    ext: extensionFor(format.mime),
    bytes: blob.size,
    originalBytes: bytes.byteLength,
    width: null,
    height: null,
    durationMs: Math.max(1, Math.min(90000, Math.round(buffer.duration * 1000))),
    features,
    sha256,
  };
}
