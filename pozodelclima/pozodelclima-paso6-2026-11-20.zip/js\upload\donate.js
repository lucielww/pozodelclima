// Flujo de donación: procesa, sube a Storage e inserta la fila `pending`.
// Nunca usa service_role. Si el insert falla, el objeto queda registrado como
// huérfano para diagnóstico y limpieza manual; la donación no se publica.

import { CONFIG } from '../config.js';
import { getSupabase } from '../supabase/client.js';
import { addDonation, addOrphan, getQuota } from '../storage/local.js';
import { DonationError, processFile } from './process.js';

const BUCKET = CONFIG.supabase?.bucket ?? 'pozo';

function config() {
  return CONFIG.donation ?? {};
}

function quota() {
  const options = config();
  return getQuota({
    limit: options.dailyQuota ?? 3,
    windowMs: options.windowMs ?? 24 * 60 * 60 * 1000,
  });
}

function withTimeout(promise, timeoutMs, code) {
  let timer = 0;

  const expired = new Promise((_, reject) => {
    timer = window.setTimeout(() => {
      reject(new DonationError(code));
    }, Math.max(1000, Number(timeoutMs) || 10000));
  });

  return Promise.race([promise, expired])
    .finally(() => window.clearTimeout(timer));
}

function createId() {
  if (!window.crypto?.getRandomValues) throw new DonationError('crypto');
  if (window.crypto.randomUUID) return window.crypto.randomUUID();

  const bytes = window.crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');

  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export async function donate(options = {}) {
  const { file, accepted, knownHashes, onStage } = options;
  const stage = typeof onStage === 'function' ? onStage : () => {};

  if (!accepted) throw new DonationError('notice');

  const before = quota();
  if (before.remaining <= 0) throw new DonationError('quota');

  stage('analizando');
  const processed = await processFile(file, { knownHashes });

  stage('subiendo');

  let supabase;
  try {
    supabase = await withTimeout(
      getSupabase(),
      config().databaseTimeoutMs ?? 8000,
      'config',
    );
  } catch (error) {
    if (error instanceof DonationError) throw error;
    throw new DonationError('config', undefined, error?.message ?? '');
  }

  if (!supabase) throw new DonationError('config');

  const id = createId();
  const path = `${id}.${processed.ext}`;
  const at = new Date().toISOString();

  let uploadError = null;
  try {
    const response = await withTimeout(
      supabase.storage.from(BUCKET).upload(path, processed.blob, {
        contentType: processed.mime,
        upsert: false,
        cacheControl: '31536000',
      }),
      config().uploadTimeoutMs ?? 30000,
      'timeout',
    );
    uploadError = response?.error ?? null;
  } catch (error) {
    if (error instanceof DonationError && error.code === 'timeout') {
      addOrphan({ id, path, at, stage: 'upload', code: 'timeout' });
      throw error;
    }
    throw new DonationError('upload', undefined, error?.message ?? '');
  }

  if (uploadError) {
    throw new DonationError('upload', undefined, uploadError.message);
  }

  stage('registrando');

  const row = {
    id,
    kind: processed.kind,
    status: 'pending',
    storage_path: path,
    mime: processed.mime,
    bytes: processed.bytes,
    width: processed.kind === 'image' ? processed.width : null,
    height: processed.kind === 'image' ? processed.height : null,
    duration_ms: processed.kind === 'audio' ? processed.durationMs : null,
    sha256: processed.sha256,
    features: processed.features,
  };

  let insertError = null;
  try {
    // Sin .select(): la fila nace pending y anon no puede leerla.
    const response = await withTimeout(
      supabase.from('pieces').insert(row),
      config().databaseTimeoutMs ?? 8000,
      'timeout',
    );
    insertError = response?.error ?? null;
  } catch (error) {
    addOrphan({ id, path, at, stage: 'insert', code: error?.code ?? 'timeout' });
    if (error instanceof DonationError && error.code === 'timeout') throw error;
    throw new DonationError('server', undefined, error?.message ?? '');
  }

  if (insertError) {
    addOrphan({
      id,
      path,
      at,
      stage: 'insert',
      code: String(insertError.code ?? ''),
    });

    if (insertError.code === '23505') {
      throw new DonationError('duplicate', undefined, insertError.message);
    }

    throw new DonationError('server', undefined, insertError.message);
  }

  addDonation({ id, path, at });
  stage('lista');

  return {
    id,
    path,
    kind: processed.kind,
    bytes: processed.bytes,
    sha256: processed.sha256,
    quota: quota(),
  };
}
