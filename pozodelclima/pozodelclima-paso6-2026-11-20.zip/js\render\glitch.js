// Glitch por slices y offset RGB.
// No clona el archivo: usa la misma imagen como fondo de dos franjas que se
// desplazan durante un instante. Solo se aplica a una minoría de piezas y se
// apaga por completo con prefers-reduced-motion.

import { makeRng, range } from '../seed/prng.js';

const MAX_GLITCH = 6;

export function applyGlitch(figure, { piece, decay, seed, index, reduced = false, budget }) {
  if (reduced || !piece || !budget || budget.used >= MAX_GLITCH) return false;
  if (!decay || decay.glitch <= 0) return false;

  const rng = makeRng(`pozo-glitch-${seed}-${piece.id}-${index}`);
  const intensity = decay.glitch;

  const layer = document.createElement('span');
  layer.className = 'piece__glitch';
  layer.setAttribute('aria-hidden', 'true');

  const isAudio = piece.kind === 'audio';
  if (isAudio) {
    layer.classList.add('piece__glitch--audio');
    layer.style.setProperty('--glitch-hue', String(Math.round(range(rng, 0, 360))));
  } else if (piece.src) {
    layer.style.setProperty('--glitch-src', `url("${piece.src}")`);
  }

  const shift = decay.glitchShift ?? range(rng, 3, 10);
  const duration = decay.glitchDuration ?? range(rng, 9, 18);

  layer.style.setProperty('--glitch-x', `${shift.toFixed(1)}px`);
  layer.style.setProperty('--glitch-y', `${(shift * range(rng, -0.3, 0.3)).toFixed(1)}px`);
  layer.style.setProperty('--glitch-dur', `${duration.toFixed(2)}s`);
  layer.style.setProperty('--glitch-delay', `${range(rng, -duration, 0).toFixed(2)}s`);
  layer.style.setProperty('--glitch-opacity', (0.3 + intensity * 0.5).toFixed(2));

  figure.querySelector('.piece__frame')?.append(layer);
  budget.used += 1;

  return true;
}
