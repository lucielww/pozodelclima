// Lectura compartida de piezas aprobadas.
// Solo se piden filas `approved`; las URLs firmadas duran una hora y se
// renuevan mientras la visita sigue abierta. Cualquier falla deja la obra
// funcionando con el seed: este módulo nunca rompe la entrada.

import { CONFIG } from '../config.js';
import { hslToCss } from '../analysis/color.js';
import { getSupabase, isSupabaseConfigured, getClientStatus } from './client.js';

const BUCKET = CONFIG.supabase?.bucket ?? 'pozo';
const SIGNED_SECONDS = CONFIG.supabase?.signedUrlSeconds ?? 3600;
const LIMIT = CONFIG.supabase?.approvedLimit ?? 60;
const DEFAULT_TIMEOUT_MS = CONFIG.supabase?.timeoutMs ?? 5000;
const URL_MARGIN_MS = 10 * 60 * 1000;
const REFRESH_EVERY_MS = 5 * 60 * 1000;

const FIELDS = 'id,kind,status,storage_path,mime,bytes,width,height,duration_ms,sha256,features,created_at';

const signedUrls = new Map(); // path -> { url, expiresAt }
let loaded = [];
let refreshTimer = 0;
let refreshing = false;
let visibilityHandler = null;

let remoteStatus = {
  state: 'inactivo',
  approved: 0,
  signed: 0,
  error: null,
  fetchedAt: 0,
  expiresAt: 0,
};

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function number(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clamp01(value) {
  return clamp(number(value, 0), 0, 1);
}

function message(error) {
  const text = error instanceof Error ? error.message : String(error ?? '');
  return (text || 'error desconocido').replace(/\s+/g, ' ').slice(0, 140);
}

function withTimeout(promise, timeoutMs, label) {
  let timer = 0;

  const expired = new Promise((_, reject) => {
    timer = window.setTimeout(() => {
      reject(new Error(`${label} no respondió en ${Math.round(timeoutMs / 1000)} s.`));
    }, timeoutMs);
  });

  return Promise.race([promise, expired])
    .finally(() => window.clearTimeout(timer));
}

function normalizeColor(value) {
  if (!value || typeof value !== 'object') return null;

  const h = Number(value.h);
  const s = Number(value.s);
  const l = Number(value.l);
  if (![h, s, l].every(Number.isFinite)) return null;

  return {
    h: ((h % 360) + 360) % 360,
    s: clamp01(s),
    l: clamp01(l),
  };
}

// Las features llegan de la base como JSON. Se normalizan acá para que un
// campo raro no rompa la selección ni el render.
function normalizePalette(value) {
  const list = Array.isArray(value) ? value.slice(0, 5) : [];

  return list
    .map((entry) => {
      const hsl = normalizeColor(entry);
      if (!hsl) return null;

      const weight = Number(entry?.weight);
      return {
        ...hsl,
        weight: Number.isFinite(weight) ? clamp01(weight) : 0.2,
        css: hslToCss(hsl),
      };
    })
    .filter(Boolean);
}

function fallbackPalette(mean) {
  return [{ ...mean, weight: 1, css: hslToCss(mean) }];
}

function normalizeImageFeatures(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const palette = normalizePalette(source.palette);
  const mean = normalizeColor(source.mean) ?? (palette[0] ?? { h: 0, s: 0, l: 0.5 });
  const colors = palette.length > 0 ? palette : fallbackPalette(mean);

  return {
    mean,
    brightness: Number.isFinite(Number(source.brightness))
      ? clamp01(source.brightness)
      : mean.l,
    saturation: Number.isFinite(Number(source.saturation))
      ? clamp01(source.saturation)
      : mean.s,
    palette: colors,
    dominant: colors[0],
  };
}

function normalizeAudioFeatures(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const palette = normalizePalette(source.palette);
  const mean = normalizeColor(source.mean) ?? { h: 188, s: 0.3, l: 0.4 };
  const colors = palette.length > 0 ? palette : fallbackPalette(mean);
  const waveform = Array.isArray(source.waveform)
    ? source.waveform.slice(0, 96).map((value) => clamp01(value))
    : [];

  return {
    duration: Math.max(0, number(source.duration, 0)),
    sampleRate: Math.max(0, number(source.sampleRate, 0)),
    rms: clamp01(number(source.rms, 0.08)),
    peak: clamp01(number(source.peak, 0.4)),
    zcr: clamp01(number(source.zcr, 0)),
    centroid: Math.max(0, number(source.centroid, 0)),
    centroidNorm: clamp01(number(source.centroidNorm, 0)),
    flatness: clamp01(number(source.flatness, 0)),
    waveform,
    mean,
    brightness: Number.isFinite(Number(source.brightness))
      ? clamp01(source.brightness)
      : mean.l,
    saturation: Number.isFinite(Number(source.saturation))
      ? clamp01(source.saturation)
      : mean.s,
    palette: colors,
    dominant: colors[0],
  };
}

function absoluteUrl(value) {
  if (typeof value !== 'string' || !value) return null;
  if (/^https?:\/\//i.test(value)) return value;

  const base = String(CONFIG.supabase?.url ?? '').replace(/\/+$/, '');
  return `${base}/storage/v1${value.startsWith('/') ? '' : '/'}${value}`;
}

// Convierte filas ya aprobadas + URLs firmadas en piezas del campo.
// Es pura para poder verificarla sin red.
export function mapApprovedRows(rows, urls) {
  if (!Array.isArray(rows) || !(urls instanceof Map)) return [];

  const pieces = [];

  for (const row of rows) {
    if (!row || typeof row !== 'object') continue;
    if (row.kind !== 'image' && row.kind !== 'audio') continue;
    if (row.status && row.status !== 'approved') continue;
    if (typeof row.id !== 'string' || row.id.length === 0) continue;

    const path = typeof row.storage_path === 'string' ? row.storage_path : '';
    const src = path ? urls.get(path) : null;
    if (!src) continue;

    const width = Math.round(number(row.width, 1000));
    const height = Math.round(number(row.height, 1000));

    pieces.push({
      id: row.id,
      kind: row.kind,
      source: 'supabase',
      src,
      storagePath: path,
      mime: typeof row.mime === 'string' ? row.mime : '',
      bytes: Math.max(0, number(row.bytes, 0)),
      sha256: typeof row.sha256 === 'string' ? row.sha256 : '',
      createdAt: typeof row.created_at === 'string' ? row.created_at : null,
      width: row.kind === 'image' ? clamp(width, 1, 20000) : 0,
      height: row.kind === 'image' ? clamp(height, 1, 20000) : 0,
      features: row.kind === 'image'
        ? normalizeImageFeatures(row.features)
        : normalizeAudioFeatures(row.features),
    });
  }

  return pieces;
}

// Une seed + aprobadas, sin duplicar IDs y sin las donaciones propias.
export function mergePieces(seedPieces, approvedPieces, ownIds = []) {
  const own = new Set(Array.isArray(ownIds) ? ownIds : []);
  const seed = Array.isArray(seedPieces) ? seedPieces.filter(Boolean) : [];
  const approved = Array.isArray(approvedPieces) ? approvedPieces.filter(Boolean) : [];
  const seen = new Set(seed.map((piece) => piece.id).filter(Boolean));
  const merged = [...seed];

  for (const piece of approved) {
    if (!piece.id || own.has(piece.id) || seen.has(piece.id)) continue;
    seen.add(piece.id);
    merged.push(piece);
  }

  return merged;
}

async function signPaths(paths) {
  const now = Date.now();
  const unique = [...new Set(paths.filter((path) => typeof path === 'string' && path.length > 0))];
  const missing = unique.filter((path) => {
    const entry = signedUrls.get(path);
    return !entry || entry.expiresAt - now < URL_MARGIN_MS;
  });

  if (missing.length > 0) {
    const supabase = await withTimeout(getSupabase(), DEFAULT_TIMEOUT_MS, 'Supabase SDK');
    if (!supabase) throw new Error('el cliente de Supabase no está disponible.');

    for (let start = 0; start < missing.length; start += 100) {
      const chunk = missing.slice(start, start + 100);
      const { data, error } = await withTimeout(
        supabase.storage.from(BUCKET).createSignedUrls(chunk, SIGNED_SECONDS),
        DEFAULT_TIMEOUT_MS,
        'Supabase Storage',
      );

      if (error) throw new Error(error.message || 'no se pudieron firmar las URLs.');

      const expiresAt = Date.now() + SIGNED_SECONDS * 1000;
      for (const item of data ?? []) {
        const url = absoluteUrl(item?.signedUrl);
        if (!item?.path || !url) continue;
        signedUrls.set(item.path, { url, expiresAt });
      }
    }
  }

  const result = new Map();
  for (const path of unique) {
    const entry = signedUrls.get(path);
    if (entry && entry.expiresAt > Date.now()) result.set(path, entry.url);
  }

  return result;
}

function expiresAtFor(pieces) {
  let min = 0;

  for (const piece of pieces) {
    const entry = signedUrls.get(piece.storagePath);
    if (!entry) continue;
    if (min === 0 || entry.expiresAt < min) min = entry.expiresAt;
  }

  return min;
}

export async function fetchApprovedPieces() {
  if (!isSupabaseConfigured()) {
    remoteStatus = {
      state: 'sin configurar',
      approved: 0,
      signed: 0,
      error: null,
      fetchedAt: 0,
      expiresAt: 0,
    };
    return { pieces: [], status: { ...remoteStatus, client: getClientStatus() } };
  }

  remoteStatus = { ...remoteStatus, state: 'cargando', error: null };

  try {
    const supabase = await withTimeout(getSupabase(), DEFAULT_TIMEOUT_MS, 'Supabase SDK');
    if (!supabase) throw new Error('no se pudo crear el cliente de Supabase.');

    const { data, error } = await withTimeout(
      supabase
        .from('pieces')
        .select(FIELDS)
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(LIMIT),
      DEFAULT_TIMEOUT_MS,
      'Supabase',
    );

    if (error) throw new Error(error.message || 'la consulta de piezas falló.');

    const rows = Array.isArray(data) ? data : [];
    // La consulta ya pide solo aprobadas, pero si una política mal configurada
    // devolviera otras filas, no se cuentan ni se muestran.
    const approvedRows = rows.filter((row) => (
      row
      && (row.status === undefined || row.status === 'approved')
      && (row.kind === 'image' || row.kind === 'audio')
    ));
    const urls = await signPaths(approvedRows.map((row) => row?.storage_path));
    const pieces = mapApprovedRows(approvedRows, urls);

    loaded = pieces;
    remoteStatus = {
      state: approvedRows.length === 0
        ? 'vacío'
        : pieces.length === approvedRows.length
          ? 'ok'
          : pieces.length === 0
            ? 'sin urls'
            : 'parcial',
      approved: approvedRows.length,
      signed: pieces.length,
      error: null,
      fetchedAt: Date.now(),
      expiresAt: expiresAtFor(pieces),
    };
  } catch (error) {
    remoteStatus = {
      state: 'error',
      approved: 0,
      signed: 0,
      error: message(error),
      fetchedAt: Date.now(),
      expiresAt: 0,
    };
  }

  return { pieces: loaded, status: { ...remoteStatus, client: getClientStatus() } };
}

export function getRemoteStatus() {
  return { ...remoteStatus, client: getClientStatus() };
}

// Hashes de las piezas aprobadas cargadas en esta visita. Se usa para rechazar
// un archivo repetido antes de subirlo; el índice único del servidor es la
// última defensa (también cubre filas pendientes que anon no puede leer).
export function getApprovedHashes() {
  return new Set(
    loaded
      .map((piece) => piece?.sha256)
      .filter((value) => typeof value === 'string' && value.length === 64),
  );
}

// Revisa cada 5 minutos y también al volver a la pestaña. Las URLs se
// renuevan cuando les queda menos de 10 minutos, sin recomponer el campo.
export function startSignedUrlRefresh(onRefresh) {
  stopSignedUrlRefresh();

  if (!isSupabaseConfigured() || loaded.length === 0) return;

  const tick = async () => {
    if (refreshing || loaded.length === 0) return;

    const now = Date.now();
    const expiring = loaded.some((piece) => {
      const entry = signedUrls.get(piece.storagePath);
      return !entry || entry.expiresAt - now < URL_MARGIN_MS;
    });

    if (!expiring) return;

    refreshing = true;

    try {
      const urls = await signPaths(loaded.map((piece) => piece.storagePath));
      let refreshed = 0;

      for (const piece of loaded) {
        const url = urls.get(piece.storagePath);
        if (url && url !== piece.src) {
          piece.src = url;
          refreshed += 1;
        }
      }

      remoteStatus = {
        ...remoteStatus,
        signed: loaded.filter((piece) => urls.has(piece.storagePath)).length,
        error: null,
        expiresAt: expiresAtFor(loaded),
      };

      if (typeof onRefresh === 'function') {
        onRefresh(loaded, { ...remoteStatus, refreshed, client: getClientStatus() });
      }
    } catch (error) {
      remoteStatus = { ...remoteStatus, error: message(error) };

      if (typeof onRefresh === 'function') {
        onRefresh(loaded, { ...remoteStatus, refreshed: 0, client: getClientStatus() });
      }
    } finally {
      refreshing = false;
    }
  };

  refreshTimer = window.setInterval(() => {
    void tick();
  }, REFRESH_EVERY_MS);

  visibilityHandler = () => {
    if (document.visibilityState === 'visible') void tick();
  };

  document.addEventListener('visibilitychange', visibilityHandler);
}

export function stopSignedUrlRefresh() {
  if (refreshTimer) {
    window.clearInterval(refreshTimer);
    refreshTimer = 0;
  }

  if (visibilityHandler) {
    document.removeEventListener('visibilitychange', visibilityHandler);
    visibilityHandler = null;
  }
}
