// Worker de análisis de audio.
// Recibe canales ya copiados desde el hilo principal y devuelve las features.
// No usa DOM ni reproduce nada: solo FFT, RMS, ZCR y envolvente.

import { analyzeAudioBuffer } from './audio.js';

self.onmessage = (event) => {
  const { channels, sampleRate } = event.data ?? {};

  if (!Array.isArray(channels) || channels.length === 0 || !channels[0]?.length) {
    self.postMessage({ features: null });
    return;
  }

  const buffer = {
    length: channels[0].length,
    numberOfChannels: channels.length,
    sampleRate: Number(sampleRate) || 44100,
    getChannelData: (channel) => channels[channel] ?? channels[0],
  };

  try {
    const features = analyzeAudioBuffer(buffer);
    self.postMessage({ features: features ?? null });
  } catch {
    self.postMessage({ features: null });
  }
};
